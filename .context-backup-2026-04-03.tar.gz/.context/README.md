# Context Index

Use this index as the first entry point before any task.

## Reading Order (Quick Start)
1. `planning/current_focus.md`
2. `planning/roadmap.md`
3. `architecture/architecture.md`
4. `architecture/modularity.md`
5. `operations/dependency_policy.md`
6. `operations/workflow.md`
7. `operations/mcp_integrations.md`
8. `operations/knowledge_memory_policy.md`

## Directory Structure
- `planning/`
  - `current_focus.md` - active sprint priorities and near-term next steps.
  - `roadmap.md` - implementation plan and phase backlog.
  - `interview.md` - historical decisions and requirement clarifications.
  - `web_admin_mvp_backlog.md` - sprint-by-sprint implementation backlog for web-admin MVP.
- `architecture/`
  - `architecture.md` - system architecture, DB model, API structure.
  - `modularity.md` - module boundaries and decomposition rules.
  - `design_system.md` - cross-platform design tokens and UI system rules.
- `product/`
  - `auth_flow.md` - authentication flows and constraints.
  - `content_refresh_pipeline.md` - screen update pipeline and validation.
  - `course_builder_platform.md` - product concept of no-code course/simulation builder.
  - `web_admin_useflow.md` - full web-admin useflow, RBAC actions, and MVP screen flow.
- `operations/`
  - `dependency_policy.md` - dependency and versioning policy.
  - `workflow.md` - branching/commit/PR/task execution standards.
  - `work_log.md` - resumable log of major implementation changes.
  - `runbook_local.md` - local environment startup and troubleshooting notes.
  - `documentation_status.md` - documentation completeness and pending items.
  - `mcp_integrations.md` - connected MCP servers and usage notes.
  - `knowledge_memory_policy.md` - rules for safe and consistent project knowledge graph memory usage.
  - `skills_catalog.md` - skill inventory relevant for this project.
- `.github/`
  - `pull_request_template.md` - required PR structure.
  - `ISSUE_TEMPLATE/*` - standardized issue intake forms.

## Logging Rule
- For non-trivial changes, update one relevant file in `.context/` before closing the task.
