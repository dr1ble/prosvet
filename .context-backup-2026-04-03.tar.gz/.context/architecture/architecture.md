# System Architecture

## 1. System Context (C4 Level 1)

The Digital Education Platform connects administrators, content creators, and students through a cohesive ecosystem.

```mermaid
C4Context
    title System Context Diagram for Digital Education Platform

    Person(admin, "Administrator", "Manages users, system settings, and content structure.")
    Person(methodologist, "Methodologist", "Creates courses, lessons, and simulation scenarios.")
    Person(student, "Student", "Consumes educational content via mobile app.")

    System_Boundary(platform, "Digital Education Platform") {
        System(web_admin, "Web Admin Panel", "Next.js/React based interface for content management.")
        System(mobile_app, "Mobile App", "Android/iOS app for learning and simulations.")
        System(backend, "Backend API", "FastAPI modular monolith handling logic and data.")
    }

    System_Ext(llm, "LLM Service", "Ollama/OpenAI for automated simulated content generation.")
    System_Ext(object_storage, "Object Storage", "S3/MinIO for media assets (images, videos, APKs).")

    Rel(admin, web_admin, "Configures system")
    Rel(methodologist, web_admin, "Authors content")
    Rel(student, mobile_app, "Learns")

    Rel(web_admin, backend, "API calls (REST/JSON)")
    Rel(mobile_app, backend, "API calls (REST/JSON)")

    Rel(backend, llm, "Generates content/metadata")
    Rel(backend, object_storage, "Stores/Retrieves assets")
```

## 2. Container Architecture (C4 Level 2)

The system is composed of three main deployable units: Web Admin, Mobile App, and Backend API, supported by data infrastructure.

```mermaid
C4Container
    title Container Diagram

    Person(student, "Student", "Mobile App User")
    Person(staff, "Staff", "Admin/Methodologist")

    Container_Boundary(c1, "User Interfaces") {
        Container(mobile, "Mobile App", "Kotlin/Compose Multiplatform", "Android-first learning application.")
        Container(web, "Web Admin", "Next.js / TypeScript", "Content management and system administration.")
    }

    Container_Boundary(c2, "Backend Services") {
        Container(api, "Backend API", "FastAPI / Python", "Modular monolith handling business logic.")
        Container(worker, "Background Worker", "Python / Celery (Planned)", "Handlers for APK scanning and heavy tasks.")
    }

    Container_Boundary(c3, "Data & Storage") {
        ContainerDb(db, "PostgreSQL", "Relational DB", "Stores users, courses, progress, and metadata.")
        Container(storage, "Object Storage", "MinIO / S3", "Stores simulation screenshots, APKs, and media.")
        Container(redis, "Redis", "Key-Value Store", "Caching, sessions, and task queues.")
    }

    Rel(student, mobile, "Uses")
    Rel(staff, web, "Uses")

    Rel(mobile, api, "HTTPS / JSON", "Fetches content, syncs progress")
    Rel(web, api, "HTTPS / JSON", "Manages content")

    Rel(api, db, "SQL (SQLAlchemy)", "Reads/Writes data")
    Rel(api, storage, "S3 API", "Uploads/Downloads media")
    Rel(api, redis, "Redis Protocol", "Cache & Pub/Sub")
    
    Rel(api, worker, "Redis Queue", "Enqueues tasks")
    Rel(worker, storage, "S3 API", "Processes assets")
```

## 3. Component Architecture (C4 Level 3)

### 3.1 Backend Modular Monolith
The backend is structured as a Modular Monolith, ensuring separation of concerns while maintaining a single deployment unit.

```mermaid
graph TD
    subgraph "Infrastructure Layer"
        Database[(PostgreSQL)]
        Storage[(Object Storage)]
    end

    subgraph "Backend Application"
        Router[API Router]
        
        subgraph "Modules"
            Auth[Auth Module]
            Users[Users Module]
            Catalog[Catalog Module]
            Simulation[Simulation Module]
            Moderation[Moderation Module]
        end
        
        Shared[Shared Kernel\n(DB, Security, Events)]
    end

    Router --> Auth
    Router --> Users
    Router --> Catalog
    Router --> Simulation
    Router --> Moderation

    Auth --> Shared
    Users --> Shared
    Catalog --> Shared
    Simulation --> Shared
    
    Shared --> Database
    Shared --> Storage
```

### 3.2 Mobile App (Compose Multiplatform)
The mobile app follows a feature-based architecture with interactions via defined APIs.

```mermaid
graph TD
    subgraph "Mobile Client"
        App[Android App Entry]
        
        subgraph "Features"
            F_Auth[Feature: Auth]
            F_Home[Feature: Home\n(Catalog, Dashboard)]
            F_Simulation[Feature: Simulation]
        end
        
        subgraph "Core Layer"
            CoreUI[Core UI Kit]
            CoreNet[Core Network]
            CoreData[Core Data/Storage]
        end
    end

    App --> F_Auth
    App --> F_Home
    App --> F_Simulation

    F_Auth --> CoreUI
    F_Auth --> CoreNet
    
    F_Home --> CoreUI
    F_Home --> CoreNet
    F_Home --> CoreData

    F_Simulation --> CoreUI
    F_Simulation --> CoreNet
    F_Simulation --> CoreData
```

## 4. Key Interaction Flows

### 4.1 Authentication Flow (Login/Password)
Secure login via login/password with refresh-session lifecycle.

```mermaid
sequenceDiagram
    participant User
    participant Mobile
    participant API
    participant DB

    User->>Mobile: Enter Login + Password
    Mobile->>API: POST /auth/login
    API->>DB: Validate Credentials
    
    alt Credentials Valid
        API->>DB: Create User Session
        API-->>Mobile: 200 OK (Access + Refresh Tokens)
        Mobile->>Mobile: Store Tokens Securely
    else Invalid Credentials
        API-->>Mobile: 401 Unauthorized
        Mobile->>User: Show Error
    end
```

### 4.2 Content Creation & delivery
How a course travels from a Methodologist's mind to a Student's screen.

```mermaid
sequenceDiagram
    participant Methodologist
    participant WebAdmin
    participant API
    participant DB
    participant Student
    participant Mobile

    Methodologist->>WebAdmin: Create Course Draft
    WebAdmin->>API: POST /authoring/courses
    API->>DB: Insert Course (Status: DRAFT)
    
    Methodologist->>WebAdmin: Add Lessons & Screens
    WebAdmin->>API: POST /authoring/lessons
    API->>DB: Insert Lessons
    
    Methodologist->>WebAdmin: Publish Release
    WebAdmin->>API: POST /moderation/publish
    API->>DB: Update Status -> PUBLISHED
    
    Student->>Mobile: Open App / Refresh
    Mobile->>API: GET /mobile/catalog/courses
    API->>DB: Query Published Courses
    API-->>Mobile: List of Courses
    Mobile->>Student: Display Courses
```

### 4.3 Simulation Simulation Flow (Planned)
The automated pipeline for capturing simulation screens from APKs.

```mermaid
sequenceDiagram
    participant Admin
    participant API
    participant Worker
    participant AutoDroid
    participant Storage

    Admin->>API: Upload APK
    API->>Storage: Save APK File
    API->>Worker: Enqueue Scan Job
    
    Worker->>AutoDroid: Start Emulator with APK
    loop Exploration
        AutoDroid->>AutoDroid: Explore UI & Screenshots
        AutoDroid->>Storage: Upload Screenshot
        AutoDroid->>Worker: Report Progress
    end
    
    Worker->>API: Job Complete (Asset IDs)
    API->>Admin: Notify Creation Ready
```

## 5. Technology Stack Summary

| Component | Technology | Reasoning |
|-----------|------------|-----------|
| **Backend** | Python, FastAPI | High performance, async, rich ecosystem (AI/ML ready). |
| **Database** | PostgreSQL | Robust relational data, complex queries support. |
| **Mobile** | Kotlin CMP | Android-first but ready for iOS. Native performance for UI. |
| **Web Admin** | Next.js (React) | Modern, fast, great developer experience, huge ecosystem. |
| **Storage** | MinIO / S3 | Scalable object storage for heavy media assets. |
| **Infrastructure** | Docker Compose | Easy local orchestration and deployment. |
