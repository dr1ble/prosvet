# Модели данных платформы цифрового обучения  
**(инфологическая, даталогическая, реляционная)**

Дата: 2026-02-22  
Статус: рабочий проектный документ (AS-IS + TO-BE)

## 1. Основание и границы

Документ собран по фактической реализации backend (`backend/app/modules/*`, Alembic миграции `0001..0008`, `9845f9f517a3`) и по продуктовым планам в `.context`:
- `.context/planning/roadmap.md`
- `.context/planning/web_admin_mvp_backlog.md`
- `.context/product/web_admin_useflow.md`
- `.context/product/course_builder_platform.md`
- `.context/product/content_refresh_pipeline.md`
- `.context/product/lesson_flow_redesign.md`

### 1.1 Зафиксированные допущения
1. **AS-IS**: в БД уже есть auth, users, catalog release storage, simulation drafts/media/library.  
2. **TO-BE (MVP+)**: будут добавлены RBAC policy tables, authoring иерархия `course -> module -> lesson -> screen`, moderation, groups/assignments/progress, audit.  
3. Есть продуктовый конфликт:
   - `web_admin_useflow`: редактирование `published` релиза разрешено,
   - `content_refresh_pipeline`: опубликованные версии immutable.
   В этой модели используется компромисс: **для MVP допускается редактирование published с полным audit trail**, но целевая архитектура рекомендует immutable publish + new release.

---

## 2. Инфологическая модель (концептуальная)

## 2.1 Доменные контуры и сущности

| Контур | Сущности | Статус |
|---|---|---|
| Identity & Auth | User, QrLoginToken, UserSession | Реализовано |
| Catalog & Releases | Course, CourseRelease, CourseReleaseScreen | Реализовано |
| Simulation | SimulationDraft, SimulationMediaAsset, SimulationLibraryItem | Реализовано |
| Authoring (структура курса) | Module, Lesson, LessonScreen, LessonReference | Планируется (LessonReference уже есть миграцией, но не интегрирован в runtime registry) |
| RBAC | Role, Permission, RolePermission, UserRole | Планируется (Sprint 2) |
| Moderation | ReleaseReview, ReviewComment, PublishDecision | Планируется |
| Learning Operations | Group, GroupMembership, Assignment, AssignmentTarget, LessonProgress | Планируется |
| Audit | AuditEvent, PolicyChangeLog | Планируется |
| Content Refresh | ScreenImportBatch, ScreenImportItem, ImportMapping | Планируется |

## 2.2 Ключевые связи (кардинальности)

### Уже в системе
- `User 1 — N UserSession`
- `User 1 — N QrLoginToken` (issuer)
- `Course 1 — N CourseRelease`
- `CourseRelease 1 — N CourseReleaseScreen`
- `User 1 — N SimulationDraft`
- `User 1 — N SimulationMediaAsset`
- `User 1 — N SimulationLibraryItem`

### Целевые (проектные)
- `Course 1 — N Module`
- `Module 1 — N Lesson`
- `Lesson 1 — N LessonScreen`
- `Lesson 1 — N LessonReference`
- `User 1 — 1 UserRole` (MVP-ограничение: одна активная роль)
- `Role N — M Permission` через `RolePermission`
- `Release 1 — N ReleaseReview`
- `Group N — M User` через `GroupMembership`
- `Assignment` назначается на `Group` и/или `User`
- `LessonProgress` фиксирует выполнение урока пользователем

## 2.3 Концептуальная ER-схема (укрупнённо)

```mermaid
erDiagram
    USER ||--o{ USER_SESSION : has
    USER ||--o{ QR_LOGIN_TOKEN : issues
    USER ||--o{ SIMULATION_DRAFT : owns
    USER ||--o{ SIMULATION_MEDIA_ASSET : uploads
    USER ||--o{ SIMULATION_LIBRARY_ITEM : owns

    COURSE ||--o{ COURSE_RELEASE : versions
    COURSE_RELEASE ||--o{ COURSE_RELEASE_SCREEN : includes

    COURSE ||--o{ MODULE : contains
    MODULE ||--o{ LESSON : contains
    LESSON ||--o{ LESSON_SCREEN : contains
    LESSON ||--o{ LESSON_REFERENCE : has

    USER ||--|| USER_ROLE : assigned
    ROLE ||--o{ USER_ROLE : maps
    ROLE ||--o{ ROLE_PERMISSION : grants
    PERMISSION ||--o{ ROLE_PERMISSION : defines

    COURSE_RELEASE ||--o{ RELEASE_REVIEW : reviewed
    USER ||--o{ RELEASE_REVIEW : performs

    GROUP_ENTITY ||--o{ GROUP_MEMBERSHIP : has
    USER ||--o{ GROUP_MEMBERSHIP : joins

    ASSIGNMENT ||--o{ ASSIGNMENT_TARGET_USER : targets
    ASSIGNMENT ||--o{ ASSIGNMENT_TARGET_GROUP : targets
    USER ||--o{ LESSON_PROGRESS : owns
    LESSON ||--o{ LESSON_PROGRESS : tracked
```

---

## 3. Даталогическая модель (PostgreSQL logical design)

## 3.1 Общие правила проектирования
- PK: `UUID`
- Временные поля: `timestamptz` (`created_at`, `updated_at`, domain-specific timestamps)
- Для динамических payload: `JSONB` (экранные структуры, графы симуляции, snippets)
- Статусы: строковые enum-like поля (`status`, `role`, `scope`, `effect`)
- Для чувствительных данных: только хэши (`refresh_token_hash`, `token_hash`)
- Archive-first подход для контента (soft-delete), где требуется бизнесом

## 3.2 AS-IS logical model (реализовано)

### Identity & Auth
- `users`
- `qr_login_tokens`
- `user_sessions`

### Catalog delivery
- `courses`
- `course_releases`
- `course_release_screens` (`payload_json`, checksum, ordered snapshot)

### Simulation
- `simulation_drafts` (unique `owner_user_id + scope_key`)
- `simulation_media_assets` (unique `storage_key`)
- `simulation_library_items`

### Важный текущий технический долг
- Миграция `9845f9f517a3` создаёт `lesson_references`, но модель не импортирована в `backend/app/models.py`.  
  Это значит: таблица может существовать в БД, но не входит в штатный metadata registry runtime.

## 3.3 TO-BE logical model (MVP+)

### RBAC
- `roles(code, name, is_system)`
- `permissions(resource, action, scope, effect)`
- `role_permissions(role_id, permission_id)`
- `user_roles(user_id, role_id, is_active, assigned_at, assigned_by_user_id)`

### Authoring (нормализованная иерархия)
- `modules(course_id, title, description, order_index, status)`
- `lessons(module_id, title, type, estimated_duration, pass_score, status, order_index)`
- `lesson_screens(lesson_id, type, title, order_index, payload_json, checksum)`
- `lesson_references(lesson_id, title, summary_text, key_points, code_snippets)`

### Moderation & publishing
- `release_reviews(release_id, reviewer_user_id, decision, comment, decided_at)`
- `release_status_history(release_id, from_status, to_status, actor_user_id, reason, changed_at)`

### Groups / assignment / progress
- `groups(name, status)`
- `group_memberships(group_id, user_id, joined_at)`
- `assignments(course_id, created_by_user_id, start_policy, starts_at, ends_at, status)`
- `assignment_target_users(assignment_id, user_id)`
- `assignment_target_groups(assignment_id, group_id)`
- `lesson_progress(user_id, lesson_id, status, completed_at, updated_at)`

### Audit
- `audit_events(actor_user_id, resource, action, scope, payload_json, created_at)`
- `policy_change_logs(actor_user_id, before_json, after_json, created_at)`

### Content refresh pipeline
- `screen_import_batches(owner_user_id, lesson_id, archive_key, status, created_at)`
- `screen_import_items(batch_id, screen_key, media_asset_id, mapping_state, validation_errors_json)`

## 3.4 Индексация и ограничения (минимальный baseline)

- `users(login)` unique nullable
- `course_releases(course_id, version)` unique
- `course_release_screens(release_id, screen_key)` unique
- `course_release_screens(release_id, order_index)` unique
- `simulation_drafts(owner_user_id, scope_key)` unique
- `group_memberships(group_id, user_id)` unique
- `user_roles(user_id)` unique where `is_active = true` (MVP single-role)
- `lesson_progress(user_id, lesson_id)` unique
- Индексы на все FK + search-поля (`title`, `slug`, `status`, `updated_at`)

---

## 4. Реляционная модель

## 4.1 AS-IS (фактическая схема)

### Таблицы
- `users(id PK, role, status, login UQ?, password_hash?, display_name?, birth_date?, created_at, updated_at)`
- `qr_login_tokens(id PK, issued_by_user_id FK->users.id, token_hash UQ, expires_at, used_at?, status, created_at)`
- `user_sessions(id PK, user_id FK->users.id, refresh_token_hash, device_id_hash?, expires_at, revoked_at?, created_at)`
- `courses(id PK, slug UQ, title, description?, status, created_at, updated_at)`
- `course_releases(id PK, course_id FK->courses.id ON DELETE CASCADE, version, changelog?, status, published_at?, created_at, UQ(course_id,version))`
- `course_release_screens(id PK, release_id FK->course_releases.id ON DELETE CASCADE, screen_key, title, order_index, payload_json JSONB, checksum, created_at, UQ(release_id,screen_key), UQ(release_id,order_index))`
- `simulation_drafts(id PK, owner_user_id FK->users.id ON DELETE CASCADE, scope_key, title, payload_json JSONB, created_at, updated_at, UQ(owner_user_id,scope_key))`
- `simulation_media_assets(id PK, owner_user_id FK->users.id ON DELETE CASCADE, scope_key, app_package_name, store_type, min_supported_version, max_supported_version, released_at?, original_filename, storage_key UQ, content_type, size_bytes, created_at)`
- `simulation_library_items(id PK, owner_user_id FK->users.id ON DELETE CASCADE, scope_key, title, target_app_name?, payload_json JSONB, created_at, updated_at)`

### Зафиксированная связь FK
- `qr_login_tokens.issued_by_user_id -> users.id`
- `user_sessions.user_id -> users.id`
- `course_releases.course_id -> courses.id`
- `course_release_screens.release_id -> course_releases.id`
- `simulation_drafts.owner_user_id -> users.id`
- `simulation_media_assets.owner_user_id -> users.id`
- `simulation_library_items.owner_user_id -> users.id`

## 4.2 TO-BE (целевая реляционная схема)

Ниже проектный слой, который добавляется поверх AS-IS:

### RBAC
- `roles(id PK, code UQ, name, is_system, created_at)`
- `permissions(id PK, resource, action, scope, effect, created_at, UQ(resource,action,scope,effect))`
- `role_permissions(role_id FK->roles.id, permission_id FK->permissions.id, PK(role_id,permission_id))`
- `user_roles(user_id FK->users.id, role_id FK->roles.id, is_active, assigned_at, assigned_by_user_id FK->users.id, PK(user_id,role_id))`

### Authoring
- `modules(id PK, course_id FK->courses.id, title, description?, order_index, status, created_at, updated_at, UQ(course_id,order_index))`
- `lessons(id PK, module_id FK->modules.id, title, type, estimated_duration, pass_score?, status, order_index, created_at, updated_at, UQ(module_id,order_index))`
- `lesson_screens(id PK, lesson_id FK->lessons.id, type, title, order_index, payload_json JSONB, checksum, created_at, updated_at, UQ(lesson_id,order_index))`
- `lesson_references(id PK, lesson_id FK->lessons.id, title, summary_text, key_points text[], code_snippets JSONB, created_at)`

### Moderation
- `release_reviews(id PK, release_id FK->course_releases.id, reviewer_user_id FK->users.id, decision, comment?, decided_at, created_at)`
- `release_status_history(id PK, release_id FK->course_releases.id, from_status, to_status, actor_user_id FK->users.id, reason?, changed_at)`

### Groups / Assignment / Progress
- `groups(id PK, name, status, created_at, updated_at)`
- `group_memberships(group_id FK->groups.id, user_id FK->users.id, joined_at, PK(group_id,user_id))`
- `assignments(id PK, course_id FK->courses.id, created_by_user_id FK->users.id, start_policy, starts_at?, ends_at?, status, created_at)`
- `assignment_target_users(assignment_id FK->assignments.id, user_id FK->users.id, PK(assignment_id,user_id))`
- `assignment_target_groups(assignment_id FK->assignments.id, group_id FK->groups.id, PK(assignment_id,group_id))`
- `lesson_progress(id PK, user_id FK->users.id, lesson_id FK->lessons.id, status, completed_at?, updated_at, UQ(user_id,lesson_id))`

### Audit
- `audit_events(id PK, actor_user_id FK->users.id, resource, action, scope, payload_json JSONB, created_at)`
- `policy_change_logs(id PK, actor_user_id FK->users.id, before_json JSONB, after_json JSONB, created_at)`

---

## 5. Решения для внедрения без слома текущего контракта

1. **Сохранить AS-IS release bundle контракт** (`course_release_screens`) для mobile синхронизации.  
2. Добавить **authoring слой** (`modules/lessons/lesson_screens`) как upstream источник; публикуемый bundle генерировать из него.  
3. Ввести RBAC таблицы отдельно от `users.role`; переход выполнить поэтапно:
   - seed roles/permissions,
   - backfill `user_roles`,
   - затем депрекейт `users.role`.
4. Все критичные переходы статусов и policy edits писать в `audit_events`.

---

## 6. Открытые вопросы (нужно финальное продуктовое решение)

1. `Published` релизы: окончательно editable или immutable?  
2. Нужен ли single-role только для MVP, или сразу проектировать multi-role?  
3. Где хранить canonical lesson screens после запуска authoring слоя:
   - только `lesson_screens`, а `course_release_screens` как snapshot,
   - или dual-write на постоянной основе?
