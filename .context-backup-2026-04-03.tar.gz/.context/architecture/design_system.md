# Design System Foundation (Web + Mobile)

## Purpose
Create one reusable UI language for:
- `web-admin` (Next.js),
- future Android app (Compose Multiplatform foundation),
- consistent UX across admin and learner surfaces.

## Token Layers
Source of truth: `design-system/tokens.json`.

1. Primitive tokens:
- raw colors (`ink`, `paper`, `signal`)
- spacing scale (`space.1..6`)
- radius scale (`sm`, `md`, `lg`)

2. Semantic tokens:
- `text.primary|secondary|muted`
- `surface.page|card|cardMuted`
- `border.default|strong`
- `feedback.success|warning|danger|info`

3. Component tokens:
- `button.primaryBg|primaryText|radius`
- `card.bg|border|radius`

Rule:
- Feature CSS should prefer semantic/component tokens.
- Primitive tokens are used only when creating/adjusting semantic tokens.

## Web Implementation
Current web mapping lives in `web-admin/app/globals.css`:
- semantic CSS variables (`--text-primary`, `--surface-card-default`, etc.)
- shared spacing/radius variables (`--space-*`, `--radius-*`)

Usage pattern:
- components use semantic variables first,
- hardcoded colors only for temporary migration or visual experiments.

## Android/Compose Mapping
Planned mapping from same token source:
- `semantic.color.surface.*` -> `MaterialTheme.colorScheme.surface*`
- `semantic.color.text.*` -> `MaterialTheme.colorScheme.onSurface*`
- `semantic.color.feedback.*` -> `MaterialTheme.colorScheme.error/tertiary`
- `primitives.space.*` -> `LocalSpacing`
- `primitives.radius.*` -> `MaterialTheme.shapes`

## UX Heuristics Rules (Mandatory)
Based on Krug + Nielsen:
- Keep one primary action per step.
- Use progressive disclosure for advanced controls.
- Avoid duplicate hints and repeated explanatory blocks.
- Surface status/errors near the action point.
- Prefer clear labels over domain jargon.

## Current Application in Simulation Builder
- `Simple/Advanced` mode split.
- `Simple` mode uses step-by-step flow (`Screens -> Hotspots -> Export`).
- Advanced tools (graph, extended validation, preview) are hidden in simple mode.

## Next Increment
1. Replace remaining hardcoded colors in simulation/catalog CSS with semantic tokens.
2. Extract reusable primitives in web-admin:
- `Button`, `Card`, `SectionHeader`, `StepSwitcher`.
3. Generate Compose token file from `design-system/tokens.json`.
