
# Kotlin Multiplatform (KMP) Migration Strategy

This document tracks the ongoing migration of the mobile application from pure Android to Kotlin Multiplatform (Android + iOS + Desktop).

## Strategic Goals
1.  **Shared Business Logic**: 100% sharing of Domain, Data, and Network layers.
2.  **Shared UI**: Migration to Compose Multiplatform (CMP) for shared UI components and eventually screens.
3.  **Platform Integration**: Native-feel integration on iOS while maximizing code reuse.

## Migration Phases

### Phase 1: Foundation & Core KMP Setup (Q1 2026)
- [x] **Build System**: Update Version Catalog and apply KMP plugins.
- [x] **Core Logic**: Convert `core:model` and `core:common` to KMP (`commonMain`).
- [x] **Feature Contracts**: Convert `feature:*:api` modules to KMP.
- [ ] **Verification**: Ensure Android app builds and runs with new module structure.

### Phase 2: Networking & Data Layer
- [x] **Network Client**: Migrate from Retrofit/OkHttp to **Ktor Client**.
- [ ] **Serialization**: Full adoption of `kotlinx.serialization`.
- [x] **Data Repository**: Move `core:data` and repositories to `commonMain`.
- [ ] **Local Storage**: Evaluate SQLDelight or Room KMP for database layer (if needed).

### Phase 3: UI Foundation (Compose Multiplatform)
- [x] **Design System**: Migrate `core:designsystem` to CMP (`org.jetbrains.compose`).
    - Move Theme/Color/Typography to `commonMain`.
    - Use `compose.resources` for string/image resources.
- [x] **UI Components**: Migrate `core:ui` to CMP.
- [x] **Image Loading**: Replace Coil with Coil 3 (KMP).

### Phase 4: Feature Implementation
- [x] **New Module**: Created `shared` module for app logic and navigation.
- [x] **Navigation**: Migrated `AppNavHost` and `DigitalEduApp` to `shared:commonMain`.
- [x] **Features**: Configured `feature:auth:impl` and `feature:home:impl` as KMP modules.
    - Moved logic (ViewModels, Screens) to `commonMain`.
    - Updated dependencies (`androidx.lifecycle` 2.8.0).
- [x] **App Integration**: Updated `app` module to use `shared` and inject repositories.

### Phase 5: New Targets
- [ ] **iOS**: Configure Xcode project and Podfile/SPM.
- [ ] **Desktop**: Configure JVM desktop target and distribution.

## Technical Decisions
- **HTTP Client**: Ktor.
- **Dependency Injection**: Koin as a shared DI container started from platform entrypoints.
- **Async**: Kotlin Coroutines (native-mt).
- **Resources**: Compose Multiplatform Resources.
- **Image Loading**: Coil 3 (Alpha/RC).
- **Navigation**: Compose Navigation (KMP).

## Progress Log
- **2026-02-08**: Phase 1 complete. Core modules and feature APIs are now KMP-ready.
- **2026-02-08**: Phase 2 Networking complete. Migrated to Ktor.
- **2026-02-09**: Phase 3 UI Foundation complete. `core:designsystem` and `core:ui` migrated to CMP. Coil 3 adopted.
- **2026-02-09**: Phase 4 Feature Implementation complete. Features and Navigation moved to KMP `shared` module.
- **2026-02-09**: Root graph extracted to `feature:root:impl`; `shared` reduced to thin app entry wrapper (`DigitalEduApp`).
