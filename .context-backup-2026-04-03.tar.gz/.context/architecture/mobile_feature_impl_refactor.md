# Mobile Feature impl Refactor (Home Decomposition)

- Date: 2026-02-25
- Status: in progress

## Problem

`mobile/feature/home/impl` одновременно содержит несколько доменов (`catalog`, `player`, `profile`) и выступает как shell-экран.
Это повышает связность и усложняет переиспользование/тестирование feature-границ.

## Target Architecture

- `feature/home` оставить как orchestration/shell (табы, эффекты верхнего уровня, маршрутизация между подфичами).
- Выделить самостоятельные feature-модули:
  - `feature/catalog/api` + `feature/catalog/impl`
  - `feature/player/api` + `feature/player/impl`
  - `feature/profile/api` + `feature/profile/impl`
- Внутри каждого `impl` придерживаться структуры:
  - `di` (Koin wiring)
  - `presentation` (ViewModel и presentation orchestration)
  - `domain` (feature-specific rules/use cases/value objects)

## Internal impl Convention

- Базовый шаблон `feature/*/impl`: `di + presentation + domain`.
- `data` внутри feature **не создается по умолчанию**, если уже есть `core:data`.
- `feature/*/impl/data` добавляется только при реальной feature-specific data логике (локальный cache/merge/adapters), иначе используется `core:data` напрямую через interfaces.

### Quick Template

```text
feature/<name>/api/
  - Intent / UiState / Effect / FeatureHost

feature/<name>/impl/
  di/
    <Name>FeatureModule.kt
  presentation/
    <Name>ViewModel.kt
  domain/
    ...UseCase.kt
    ...Action.kt
    ...Outcome.kt
```

- Подробный шаблон: `mobile/docs/feature-impl-template.md`

## KMP Boundaries

- API-модуль публикует минимальный контракт (entry composable / state contracts / callbacks).
- Impl-модуль содержит DI, VM и детали реализации.
- `home/impl` зависит от `api` подфич, но не от их внутренних деталей.

## Migration Plan (Incremental)

1. [x] Вынести `catalog` в отдельный `feature/catalog` модуль (без изменения UX).
2. [x] Вынести `player` в отдельный `feature/player` модуль.
3. [x] Вынести `profile` в отдельный `feature/profile` модуль.
4. [x] Упростить `home/impl` до shell-композиции.
5. [x] Добавить модульные тесты на API-контракты подфич.

## Progress Notes

- 2026-02-25:
  - добавлены модули `feature:catalog:api` и `feature:catalog:impl`;
  - `CatalogIntent/CatalogUiState/CatalogEffect` и контракт `CatalogFeatureHost` вынесены в `catalog-api`;
  - `CatalogViewModel` и DI-модуль вынесены в `catalog-impl`;
  - `home-impl` переведен на зависимость от `catalog-api` (без прямого импорта `catalog-impl`);
  - подключение `catalogFeatureModule()` централизовано через `shared` DI.

- 2026-02-25:
  - добавлены модули `feature:profile:api` и `feature:profile:impl`;
  - `ProfileIntent/ProfileUiState/ProfileStatus/ProfileEffect` и контракт `ProfileFeatureHost` вынесены в `profile-api`;
  - `ProfileViewModel` и DI-модуль вынесены в `profile-impl`;
  - `home-impl` переведен на зависимость от `profile-api` (без прямого импорта `profile-impl`);
  - подключение `profileFeatureModule()` централизовано через `shared` DI.

- 2026-02-25:
  - добавлены модули `feature:player:api` и `feature:player:impl`;
  - `PlayerIntent/PlayerUiState/PlayerEffect` и контракт `PlayerFeatureHost` вынесены в `player-api`;
  - `PlayerViewModel`, `SimulationUrlResolver`, `SavedCourseProgress` и DI-модуль вынесены в `player-impl`;
  - `home-impl` переведен на зависимость от `player-api` (без прямого импорта `player-impl`);
  - подключение `playerFeatureModule()` централизовано через `shared` DI.

- 2026-02-25:
  - `home-impl` очищен от доменных реализаций `catalog/player/profile` и теперь содержит shell orchestration + UI-композицию;
  - добавлены базовые контрактные тесты для `catalog-api`, `profile-api`, `player-api` (проверка default-state и базовых инвариантов контрактов).

- 2026-02-25:
  - `catalog-impl`, `profile-impl`, `player-impl` приведены к внутренней структуре `di/presentation/domain` с переносом файлов и package namespace;
  - решение по data-layer зафиксировано: использовать `core:data` как основной источник, feature-local `data` вводить только по необходимости.

- 2026-02-25:
  - в `player-impl` начато планомерное утончение presentation-слоя: часть логики перенесена из `PlayerViewModel` в `domain` use-case классы (`ProgressTransitionUseCase`, `RestoreCourseProgressUseCase`, `ResolveReferenceIdUseCase`);
  - для use-case логики добавлены отдельные jvm unit tests.

- 2026-02-25:
  - навигационная orchestration в `player-impl` декомпозирована в domain слой:
    - `ResolveNavigationUseCase` + `NavigationCommand/NavigationOutcome`
    - `ResolveHotspotActionUseCase` + `HotspotAction`
  - `PlayerViewModel` переведен на use-case oriented flow (`navigate(command)`) с сохранением поведения.

- 2026-02-25:
  - `catalog-impl` приведен к use-case oriented presentation:
    - `LoadCoursesUseCase`
    - `OpenCourseBundleUseCase`
  - `CatalogViewModel` больше не зависит напрямую от `CatalogRepository`, а использует domain use-cases.

- 2026-02-25:
  - `profile-impl` приведен к use-case oriented presentation:
    - `LogoutUseCase`
  - `ProfileViewModel` больше не зависит напрямую от `AuthRepository`, а использует domain use-case.

## Success Criteria

- В `home/impl` нет бизнес-логики доменных подфич.
- Каждая подфича собирается и тестируется изолированно.
- Зависимости направлены только через `api` контракты.
