# Modularity Guidelines

## Purpose
- Enforce a scalable modular architecture across backend, web, and mobile.
- Reduce coupling and simplify new feature additions.

## Global Rules
- Each feature belongs to a named module with explicit boundaries.
- Cross-module access is allowed only via public interfaces/contracts.
- Shared utilities must remain infrastructure-only; no domain leakage.
- New feature should first define module contract, then implementation.

## Backend (FastAPI) Suggested Structure
```text
backend/
  app/
    modules/
      auth/
        api/
        domain/
        infra/
      users/
      catalog/
      authoring/
      simulation/
      moderation/
      content_refresh/
      favorites/
      progress/
      audit/
    shared/
      db/
      security/
      events/
```

Rules:
- `api/` contains routers and DTO adapters only.
- `domain/` contains use-cases and business rules.
- `infra/` contains repositories and integrations.
- No direct module-to-module DB access; use service contracts.

## Web Admin (Next.js) Suggested Structure
```text
web-admin/
  src/
    features/
      auth/
      users/
      catalog/
      authoring/
      moderation/
      content-refresh/
    entities/
    shared/
```

Rules:
- Keep domain hooks/services inside feature modules.
- UI components can be shared, but feature state is isolated.
- API clients are typed and grouped by feature.

## Mobile (Kotlin Compose Multiplatform) Suggested Structure
```text
mobile/
  core/
    network-api
    storage-api
    ui-kit
  features/
    auth-api
    auth-impl
    lessons-api
    lessons-impl
    simulation-api
    simulation-impl
    favorites-api
    favorites-impl
```

Rules:
- `*-api` exposes contracts/models only.
- `*-impl` depends on corresponding `*-api` and core modules.
- Avoid direct `impl -> impl` dependencies between features.
- Navigation layer depends on feature APIs, not implementations.

## Definition of Done for a New Module
1. Module contract documented.
2. Directory and boundary rules applied.
3. Tests added for domain behavior.
4. API/schema docs updated if contract changed.
5. `.context/` files updated with new decisions.
