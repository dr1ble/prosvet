# Backend Backlog

Derived from Web Admin MVP Sprints and APK Pipeline research.

## High Priority (MVP Sprints)

### Sprint 2: RBAC Policy Engine
- [ ] **Database Schema**: Create `roles`, `permissions`, `role_permissions`, `user_roles` tables.
- [ ] **Policy Evaluator**: Implement `deny > allow` logic with scopes (`global`, `group`, `own`).
- [ ] **Admin API**: Endpoints for policy management (`/api/v1/admin/policies/*`).
- [ ] **User Permission API**: Update `/api/v1/auth/me` to return computed permission set.

### Sprint 3: Course Management
- [ ] **CRUD Endpoints**: `courses`, `modules`, `lessons` (create, read, update, archive/restore).
- [ ] **Ordering**: Endpoints for drag-and-drop reordering with transactional reindex.
- [ ] **Isolation**: Enforce course isolation (no cross-course content sharing).

### Sprint 4 & 5: Content Types
- [ ] **Screen Entity**: CRUD for screens with types (`video`, `simulation`, `quiz`, `summary`).
- [ ] **Simulation Validation**: Graph consistency checks (reachable nodes, dead-ends).

### Sprint 6: Release Workflow
- [ ] **State Machine**: Implement transitions `draft -> review -> approved -> published`.
- [ ] **Versioning**: `app_version_range` validation.
- [ ] **Moderation**: Comments and reject reasons storage.

### Sprint 7: Operations
- [ ] **Groups**: CRUD and user-group membership.
- [ ] **Assignments**: Course assignment logic (group/individual).
- [ ] **Progress**: Query endpoints for completed lessons.
- [ ] **Search**: Global search endpoint across all entities.

## Medium Priority (APK Pipeline & Security)
- [ ] **APK Pipeline API**
  - `POST /api/v1/simulation/apk-scan` endpoint.
  - `ApkScanJob` model (status, progress, results).
  - Background worker for job processing.
  - `POST /api/v1/simulation/media/upload` (internal/secured).
- [ ] **Security Hardening**
  - Rate limiting on auth endpoints.
  - Protected storage for sensitive fields.

## Low Priority (Phase 2)
- [ ] **Analytics Module**: Funnel, drop-off, popularity metrics.
- [ ] **Cybersecurity Trainer**: Special scenarios support.
