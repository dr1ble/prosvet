# Design Backlog

Derived from UX/UI requirements and "Aesthetics" guidelines.

## High Priority (Mobile)
- [ ] **Accessibility Standards**:
  - Design guidelines for Large Fonts.
  - Design guidelines for High Contrast mode.
- [x] **Lesson Playback UX**:
  - Redesign proposed in `.context/product/lesson_flow_redesign.md`.
  - [ ] Implement "Guided Learning Path".
  - [ ] Implement Fullscreen Simulation.
  - [ ] Implement Quiz & Cheat Sheet.

## High Priority (Web Admin)
- [ ] **RBAC Policy Editor**: UX for complex permission management.
- [ ] **Course Tree Interaction**: Drag-and-drop visuals and states.
- [ ] **Simulation Builder**:
  - Graph visualization style.
  - Hotspot editing interactions.
- [ ] **Moderation Dashboard**: efficient review workflow layout.

## Visual Polish
- [ ] **Design System**: Refine color palette and typography (Inter/Roboto/Outfit).
- [ ] **Micro-animations**: Button states, loading states, success/error feedback.
- [ ] **Dark Mode**: Verify color contrast and visual hierarchy in dark themes.
