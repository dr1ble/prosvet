# DevOps Backlog

Derived from Infrastructure requirements and APK Pipeline architecture.

## High Priority (MVP)
- [ ] **CI/CD Checks**:
  - Define base verification checks (lint, tests, type-check) for all repos.
  - Github Actions / GitLab CI pipelines.
- [ ] **HTTPS Configuration**: Enforce HTTPS-only for production.
- [ ] **Database Backups**: Implement daily PostgreSQL backup job to object storage.

## Medium Priority (APK Pipeline)
- [ ] **Pipeline Infrastructure**:
  - Docker Compose for `Ollama` + `Android Emulator` + `AutoDroid`.
  - Provisioning of KVM-enabled runner (VPS or local machine).
  - Setup `scan_apk.py` script and integration with Backend.

## Research / Low Priority
- [ ] **Monitoring**: Setup basic health checks and alerts.
- [ ] **Log Aggregation**: Centralized logging (e.g., if moving to k8s/cloud).
