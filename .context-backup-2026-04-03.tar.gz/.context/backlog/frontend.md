# Frontend (Web Admin) Backlog

Derived from Web Admin MVP Sprints and APK Pipeline research.

## High Priority (MVP Sprints)

### Sprint 2: RBAC Policy Editor
- [ ] **Policy Editor UI**: Admin-only interface for resource/action toggles.
- [ ] **Role Preview**: Visualizer for role permissions.
- [ ] **Audit Log**: View policy change history.

### Sprint 3: Course Structure
- [ ] **Tree Layout**: Left panel for course structure.
- [ ] **Drag-and-Drop**: Reordering for modules and lessons.
- [ ] **CRUD Forms**: Create/Edit/Archive flows with validation.

### Sprint 4: Screen Editor
- [ ] **Screen Management**: List editor inside lessons.
- [ ] **Screen Types**: Forms for `video`, `quiz` (time limit, passing score), `summary`.

### Sprint 5: Simulation Builder (Enhancements)
- [ ] **Graph Editor**: Visual transition graph editing.
- [ ] **Preview Mode**: Runner to test simulation flows.
- [ ] **Hint Editor**: Visual editing of hints (nudge, zones).

### Sprint 6: Release & Moderation
- [ ] **Release Panel**: Status actions (`Publish`, `Request Review`).
- [ ] **Moderation Queue**: Interface for moderators to review content.
- [ ] **History**: View past releases and moderation comments.

### Sprint 7: Operations UI
- [ ] **Groups Management**: Create groups, manage members.
- [ ] **Assignments**: Assign courses to groups/users.
- [ ] **Progress View**: Operational view of learner progress.
- [ ] **Global Search**: Top shell integration.

## Medium Priority (APK Pipeline)
- [ ] **APK Scan UI**:
  - Upload form for APKs.
  - Progress bar for scanning jobs.
  - Screenshot gallery for review/selection.

## Hardening (Sprint 8)
- [ ] **UX Polish**: Accessibility pass, error handling normalization.
- [ ] **E2E Tests**: Smoke flows for critical paths.
