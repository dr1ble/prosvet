# Mobile Backlog

Derived from Phase 1 MVP goals and Phase 2 features.

## High Priority (MVP)
- [ ] **Lesson Playback Flow**
  - Implement sequential navigation: Video -> Simulation -> Summary.
  - Handle state transitions and progress saving.
- [ ] **Smart Hints**
  - Show hints on inactivity or repeated mistakes during simulations.
- [ ] **Favorites**
  - Ability to mark courses/lessons as favorites.
- [ ] **Accessibility (Phase 1 Baseline)**
  - Implement Large Font mode support.
  - Implement High Contrast mode support.

## Medium Priority (Phase 2)
- [ ] **Offline Mode**
  - Content caching strategy.
  - Deferred synchronization of progress.
  - Conflict resolution (`last_write_wins`).
- [ ] **SOS Notifications**
  - Telegram integration.
  - Push notifications to curator app.
- [ ] **Voice Features**
  - Voice search.
  - Text-to-Speech (TTS) for lesson content.

## Low Priority / Future
- [ ] **AI Features**
  - Auto-summary generation for users.
  - Intelligent learning assistance.
