# Course Builder — No-Code Editor

## Decision Date
2026-03-31

## Problem
Existing course creation tools are fragmented:
- **Course Wizard** (`/course-wizard/[courseId]`): step-by-step form, no visual editing, no post-publish editing
- **Simulation Editor** (`/simulation-v2`): full React Flow editor for simulations only
- **Catalog Workspace** (`/catalog`): course list + inline lesson/task creation, no visual structure

No unified visual course builder exists. Methodologists cannot:
- See entire course structure at a glance
- Drag & drop reorder lessons/tasks
- Edit content inline without leaving the builder
- Preview course as a student before publishing
- Easily edit a published course

## Decision
Build a **sidebar + content** course builder (Figma-like UX):
- **Left sidebar**: course tree with drag & drop reorder
- **Main area**: inline content editor for selected task
- **React Flow only for simulations**: embedded from existing `/simulation-v2` code
- **NOT three-panel layout**: course is hierarchical (not a graph), three panels overload UX

## Rejected Alternatives
1. **Three-panel layout (tree + canvas + properties)**: Rejected — cognitive overload, React Flow overkill for linear course structure
2. **Single-column Notion-style**: Rejected — can't see structure at a glance, bad for long courses
3. **Table Airtable-style**: Rejected — content editing requires modal/dialog, breaks flow

## Architecture

### Layout
```
┌──────────┬───────────────────────────────────────┐
│ SIDEBAR  │  CONTENT AREA                         │
│          │                                       │
│ 📚 Курс  │  Selected task editor:                 │
│ ├ Урок 1 │  - TextTaskEditor (Tiptap)            │
│ ├ Урок 2 │  - VideoTaskEditor (URL + transcript) │
│ └ Урок 3 │  - QuizTaskEditor (questions)         │
│          │  - SimulationTaskEditor (embedded)    │
│          │  - CheatSheetEditor                   │
│          │                                       │
└──────────┴───────────────────────────────────────┘
```

### Tech Stack
| Package | Purpose | Phase |
|---------|---------|-------|
| `@dnd-kit/core` + `@dnd-kit/sortable` | Drag & drop reorder in sidebar | MVP (Phase 1) |
| `@tiptap/react` | Rich text editor for theory_text | Phase 2 |
| `zod` | Payload validation | Phase 2 |
| `@xyflow/react` | Already installed — reused for simulations | Phase 4 |
| `zustand` | Already installed — state management | MVP |
| `lucide-react` | Already installed — icons | MVP |
| Tailwind v4 + CSS custom props | Already installed — styling | MVP |

### Component Structure
```
web/src/features/course-builder/
├── store.ts                          # Zustand store
├── api.ts                            # API client
├── types.ts                          # TypeScript types
├── ui/
│   ├── CourseBuilderLayout.tsx       # Main layout
│   ├── CourseBuilderHeader.tsx       # Header with status/actions
│   ├── sidebar/
│   │   ├── CourseTreeSidebar.tsx     # Tree with dnd-kit
│   │   ├── LessonNode.tsx            # Lesson tree node
│   │   └── TaskNode.tsx              # Task tree node
│   ├── content/
│   │   ├── ContentArea.tsx           # Main content area
│   │   ├── TaskEditor.tsx            # Editor router by task type
│   │   ├── TextTaskEditor.tsx        # theory_text editor
│   │   ├── VideoTaskEditor.tsx       # theory_video editor
│   │   ├── QuizTaskEditor.tsx        # Quiz constructor
│   │   ├── CheatSheetEditor.tsx      # Cheat sheet editor
│   │   └── SimulationTaskEditor.tsx  # Simulation wrapper
│   └── publish/
│       └── PublishDialog.tsx         # Publish with validation
└── hooks/
    ├── useAutosave.ts                # Debounced autosave
    └── useValidation.ts              # Pre-publish validation
```

### Backend Changes
New endpoint:
```
POST /api/v1/courses/{course_id}/structure/bulk
Body: { lessons: [{ id, order_index, tasks: [{ id, order_index, payload_json }] }] }
```

### Simulation Integration Plan
1. Extract `<SimulationCanvas />` from `SimulationEditor.tsx` into shared component
2. `SimulationEditor.tsx` becomes a wrapper (legacy route compatibility)
3. Course builder uses `<SimulationCanvas embedded />` for simulation tasks

## Implementation Phases

### Phase 0: Foundation
- [ ] Bulk update API endpoint
- [ ] Zustand store scaffold
- [ ] API client with fetch + cache
- [ ] TypeScript types for builder entities

### Phase 1: MVP — Visual Structure Editor
- [ ] Sidebar with course tree (lessons + tasks)
- [ ] Drag & drop reorder (dnd-kit)
- [ ] Add/delete lessons and tasks
- [ ] Inline rename (click-to-edit)
- [ ] Properties panel for selected task
- [ ] Simulation binding (select from library)
- [ ] Autosave (2s debounce)

### Phase 2: Inline Content Editors
- [ ] TextTaskEditor (Tiptap markdown)
- [ ] VideoTaskEditor (URL + transcript)
- [ ] CheatSheetEditor

### Phase 3: Quiz Constructor
- [ ] single_choice, multiple_choice, matching questions
- [ ] Validation (min 2 options, 1+ correct)

### Phase 4: Simulation Integration
- [ ] Extract SimulationCanvas shared component
- [ ] Embedded mode in course builder
- [ ] Library selection dropdown

### Phase 5: Live Preview
- [ ] Mobile frame preview
- [ ] Content rendering for all task types
- [ ] Interactive simulation preview

### Phase 6: Publishing
- [ ] Publish dialog with validation
- [ ] Version/changelog input
- [ ] Version diff view

## Relations
- Replaces: Course Wizard (eventually, keep as fallback)
- Extends: Simulation Editor v2 (embedded mode)
- Uses: Catalog module API (lessons, tasks, releases)
- Feeds: Mobile app (via published releases)

## Quality Gates
Before publish, block if:
- No lessons in course
- Lesson has no tasks
- Required task has empty payload
- Simulation task has no simulation bound
- Quiz has no questions
