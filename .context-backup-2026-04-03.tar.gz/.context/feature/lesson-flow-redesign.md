# Lesson Flow Redesign: Guided Learning Path

## 1. Overview and UX Audit

### Goal
Transition from a linear "presentation" model to a **"Guided Learning Path"**. This approach contextualizes simulations with theory and uses active learning patterns (Concept -> Practice -> Review).

### Current State vs. Future State
- **Current:** Linear pager of screens. Only `Simulation` is fully implemented. Navigation is strictly previous/next.
- **Future:**
    - **Vertical Stack** for content consumption (Video/Article).
    - **Immersive Mode** for Simulations and Videos.
    - **Integrated Context:** Theory accessible via "Cheat Sheet" during simulation.
    - **Explicit Content Types:** `Video`, `Article`, `Simulation` (with context), `Quiz`.

### UX Flow
1.  **Introduction (Prime):** Video or Article introduces the concept.
2.  **Practice (Prompt):** "Start Simulation" card. Launches immersive fullscreen experience.
    - **Context:** User can open a "Theory" bottom sheet inside the simulation.
3.  **Review (Prove):** Quiz to verify understanding.
4.  **Retention:** "Cheat Sheet" unlocked and saved to user profile.

---

## 2. Technical Specification (Backend)

### 2.1 Data Models

The backend must serve polymorphic `ScreenPayload` types.

#### `ScreenPayload` Definitions

1.  **`VideoPayload` ("video")**
    - `video_url`: string (URL)
    - `duration_sec`: integer
    - `transcript`: optional string (Markdown)

2.  **`ArticlePayload` ("article")**
    - `markdown_content`: string
    - `assets`: list of strings (URLs)

3.  **`SimulationPayload` ("simulation")**
    - `image_url`: string
    - `hotspots`: list of `Hotspot` objects
    - `context_ref`: optional string (ID linking to `LessonReference`)

4.  **`QuizPayload` ("quiz")**
    - `questions`: list of `QuizQuestion` objects
    - `QuizQuestion`:
        - `id`: string
        - `type`: "single_choice" | "multiple_choice" | "matching"
        - `text`: string
        - `explanation`: string
        - `options`: list of `{id, text}`

#### New Entity: `LessonReference` (Cheat Sheet)
- **Purpose:** Persistent summary for the user.
- **Schema:**
    - `lesson_id`: string (Foreign Key)
    - `title`: string
    - `summary_text`: string
    - `key_points`: list of strings
    - `code_snippets`: list of `{label, code, language}`

### 2.2 API Endpoints

1.  **`GET /courses/{course_id}/lessons/{lesson_id}`**
    - **Update:** `payload` field in response must follow the new `ScreenPayload` polymorphism.

2.  **`GET /users/me/references`**
    - List unlocked cheat sheets.

3.  **`GET /users/me/references/{lesson_id}`**
    - Get specific cheat sheet.

4.  **`POST /users/me/references`** (Internal/System)
    - Triggered on lesson completion.

---

## 3. Implementation Plan

### Phase 1: Mobile Core & UI (Completed)
- [x] Defined `ScreenPayload` sealed interface (Video, Article, Quiz).
- [x] Created `LessonReference` models.
- [x] Implemented `LessonPlayerScreen` with "Immersive Mode".
- [x] Implemented `LessonCheatSheetView` (UI).

### Phase 2: Backend Implementation (Pending)
- [ ] Refactor `ScreenPayload` serialization in `backend/app/modules/catalog`.
- [ ] Create `LessonReference` model in `backend/app/modules/catalog` (or new module).
- [ ] Implement API endpoints for References.

### Phase 3: Integration
- [ ] Mobile: Connect `VideoPlayer`, `ArticleViewer`, `QuizView` to real data.
- [ ] Mobile: Fetch `LessonReference` from API.
