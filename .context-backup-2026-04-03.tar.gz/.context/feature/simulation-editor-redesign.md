# Simulation Editor Redesign: Figma-like Interface

**Дата:** 2026-02-11  
**Статус:** Планирование  
**Owner:** TBD

## Цель

Переработать `simulation-builder.tsx` (3019 строк) в unified Figma-like интерфейс на React Flow с drag-and-drop для экранов, hotspots и transitions.

## Текущее состояние

- **Файл:** `web-admin/src/features/simulation/ui/simulation-builder.tsx` (3019 строк)
- **Архитектура:** Монолитный компонент со StepSwitcher (3 шага)
- **Проблема:** Нет unified интерфейса, сложно редактировать transitions/hints

## Целевое состояние

Unified Figma-like интерфейс:
- Слева: Tools Panel (Presets + Media + Screens)
- Центр: Infinite Canvas (React Flow)
- Справа: Properties Panel
- Сверху: Toolbar

## Технологии

- `@xyflow/react` (React Flow v12)
- react-dnd для drag из panels
- CSS Modules (существующий стек)

## Структура файлов

```
simulation/ui/
├── SimulationEditor.tsx         # Main component (~200 строк)
├── canvas/
│   ├── ScreenNode.tsx          # Экран: img + title + handles
│   ├── ScreenHandle.tsx         # 4 точки соединения
│   ├── HotspotOverlay.tsx      # Rect для hotspot drawing
│   └── TransitionEdge.tsx       # Связь между экранами
├── panels/
│   ├── ToolsPanel.tsx          # Левый: Presets + Media + Screens
│   └── PropertiesPanel.tsx      # Правый: свойства выбранного
└── toolbar/
    └── EditorToolbar.tsx       # Save/Preview/Export/Zoom
```

## Layout

```
┌─────────────────────────────────────────────────────────────────┐
│ 🧪 EditorToolbar: [Save] [Preview] [Export] [Zoom: - + 100%]   │
├────────┬───────────────────────────────────────────┬────────────┤
│ Tools  │         Infinite Canvas                  │ Properties │
│ Panel  │    (Drag screens, draw hotspots)         │ (selected │
│        │                                           │  element) │
│ [📱]   │    ┌─────────┐      ┌─────────┐         │            │
│ [🎯]   │    │ Screen  │──────▶│ Screen  │         │            │
│ [🔗]   │    │   1     │      │   2     │         │            │
│        │    └─────────┘      └─────────┘         │            │
│        │                                           │            │
├────────┴───────────────────────────────────────────┴────────────┤
│ 💾 Saved at 14:30 | 🔍 Validation: 0 errors | 📐 Zoom: 100%    │
└─────────────────────────────────────────────────────────────────┘
```

## Функциональность

| Функция | Реализация |
|---------|------------|
| Добавить экран | Drag из Screens Panel на canvas |
| Переместить экран | Drag ноды |
| Нарисовать hotspot | Toggle "Draw" → click-drag на ScreenNode |
| Редактировать hotspot | Клик → Properties Panel |
| Создать transition | Drag от handle к другой ноде |
| Preview | Read-only React Flow mode |
| Export | JSON для каталога |
| Save | Auto-save на change + ручной save |

## Components

### ScreenNode
- thumbnail изображения
- Название экрана + номер
- 4 handles для transitions (top, right, bottom, left)
- Фиксированный размер (по размеру thumbnail)
- HotspotOverlay поверх изображения

### TransitionEdge
- Bezier curve между handles
- Label с номером transition
- Возможность редактирования

### HotspotOverlay
- Div поверх ScreenNode
- Полупрозрачный overlay
- Click-drag для создания rect
- Resize handles

### ToolsPanel
- Tabs: Presets, Media, Screens
- Presets: Blank, Bank, Gov, Messenger
- Media: Upload + library
- Screens: Список экранов с drag

### PropertiesPanel
- Контекстная - зависит от выбранного:
  - Screen: title, imageUrl, isCompletion, delete
  - Hotspot: label, hint, target screen, delete
  - Transition: delete

### EditorToolbar
- Save button (with auto-save indicator)
- Preview toggle (read-only mode)
- Export JSON button
- Zoom controls (-, +, 100%)
- Layout toggle (auto/none)

## Этапы реализации

### Этап 1: База
- Установить `@xyflow/react`
- Создать `SimulationEditor.tsx` с layout
- Настроить React Flow provider
- Basic canvas с zoom/pan

### Этап 2: ScreenNode + Screens Panel
- `ScreenNode.tsx` - thumbnail + title + handles
- `ScreensPanel.tsx` - drag sources
- Drop zone на canvas → добавить экран
- Screen ordering через позиционирование

### Этап 3: Transitions
- `TransitionEdge.tsx` - стрелка с label
- Drag от handles → создать связь
- Валидация: нет циклов, все связи валидны

### Этап 4: Hotspots
- `HotspotOverlay.tsx` - div поверх ScreenNode
- Draw mode: click → start, drag → size
- HotspotProperties - label, hint, target screen

### Этап 5: Toolbar + Preview
- `EditorToolbar`: Save, Preview toggle, Export
- Preview mode: read-only React Flow
- Auto-save на change

### Этап 6: Presets/Media/Library
- Перенести существующий функционал
- Collapsible panels для Presets, Media, Library
- Extract from store → оставить

## Модель данных

```typescript
interface SimulationEditorState {
  screens: ScreenNode[];
  edges: TransitionEdge[];
  selectedId: string | null;
  selectedType: 'screen' | 'hotspot' | 'transition' | null;
  mode: 'select' | 'draw' | 'connect';
  zoom: number;
  validationErrors: ValidationError[];
}
```

## Валидация

- Нет циклов в графе
- Все экраны достижимы из startScreen
- Каждый hotspot имеет targetScreen
- Минимум 1 экран

## Существующий функционал для миграции

| Функция | Статус | Куда |
|---------|--------|------|
| Presets (Blank, Bank, Gov, Messenger) | ✅ | ToolsPanel/Presets |
| Media library upload | ✅ | ToolsPanel/Media |
| Extract from store URL | ✅ | ToolsPanel/Media |
| Library save/load | ✅ | ToolsPanel/Library |
| Validation | ✅ | Toolbar/Status |
| Export JSON | ✅ | Toolbar/Export |
| Preview mode | ✅ | Toolbar/Preview |

## Out of Scope

- Auto-layout algorithms (dagre/ELK) - v2
- Multiple selection - v2
- Undo/redo - v2
- Collaborative editing - v2

## Definition of Done

- [ ] Screens drag-and-drop работает
- [ ] Hotspots можно размечать (draw + resize)
- [ ] Transitions соединяют экраны (drag от handles)
- [ ] Preview mode доступен и работает корректно
- [ ] Export JSON работает
- [ ] Существующий функционал (presets, media, library) сохранён
- [ ] Валидация показывает ошибки графа
- [ ] Auto-save при изменениях
- [ ] Lint + type-check проходят
- [ ] Тесты проходят

## Риски

| Риск | Mitigation |
|------|------------|
| React Flow learning curve | Использовать @xyflow/react с документацией |
| Производительность при_many/screens | React Flow virtualization |
| Сложность hotspot drawing | Простой overlay div + mouse events |
| Breaking changes API | Lock версии @xyflow/react |

## Timeline

| Этап | Оценка |
|------|--------|
| Этап 1: База | 1-2 дня |
| Этап 2: ScreenNode + Screens | 2-3 дня |
| Этап 3: Transitions | 1-2 дня |
| Этап 4: Hotspots | 2 дня |
| Этап 5: Toolbar + Preview | 1-2 дня |
| Этап 6: Presets/Media/Library | 1-2 дня |
| **Всего** | **8-13 дней**
