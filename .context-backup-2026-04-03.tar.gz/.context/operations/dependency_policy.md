# Dependency Policy

## Goal
- Keep dependencies up to date, secure, and aligned with current best practices.

## Core Rules
- Use latest stable versions by default.
- Do not use alpha/beta/rc versions unless explicitly justified.
- Prefer actively maintained libraries with clear release cadence.
- Every significant dependency add/upgrade must include a short decision note.

## Source Priority for Best Practices
1. `context7` MCP (primary for library usage patterns and API examples).
2. `deepwiki` MCP (repository-specific docs and architecture notes).
3. Official docs/changelog/release notes (fallback if MCP context is missing).

## Workflow for Add/Upgrade
1. Check latest stable version.
2. Verify recommended usage pattern (avoid deprecated APIs).
3. Validate compatibility with current stack.
4. Update lockfile and run tests/lint/type-check.
5. Record decision in this file.

## Decision Log Template
- Date:
- Package:
- Version:
- Why selected:
- Source used (`context7`/`deepwiki`/official docs):
- Compatibility notes:

## Current Baseline (to maintain)
- Backend:
  - `FastAPI`
  - `SQLAlchemy`
  - `Alembic`
- Web:
  - `Next.js`
  - `React`
  - `TypeScript`
- Mobile:
  - `Kotlin Compose Multiplatform`

Note:
- Pin exact resolved versions in project manifests/lockfiles once repositories are scaffolded.

## Decision Log
- Date: 2026-02-05
- Package: `lint-staged`
- Version: `16.2.7` (from `web-admin/package-lock.json`)
- Why selected: staged-only formatting in pre-commit to keep commits clean and fast.
- Source used (`context7`/`deepwiki`/official docs): official npm release channel.
- Compatibility notes: works with current Node.js `v24.4.1` and npm `11.4.2`.

- Date: 2026-02-05
- Package: `prettier`
- Version: `3.8.1` (from `web-admin/package-lock.json`)
- Why selected: deterministic formatting for web/admin files and docs in commit pipeline.
- Source used (`context7`/`deepwiki`/official docs): official npm release channel.
- Compatibility notes: integrated through `lint-staged` and `npm run format:check`.

- Date: 2026-02-05
- Package: `ruff`
- Version: `0.15.0`
- Why selected: fast Python linting in pre-commit for staged backend Python files.
- Source used (`context7`/`deepwiki`/official docs): official PyPI release channel.
- Compatibility notes: installed with Python `3.13.5`; invoked as `python3 -m ruff`.

- Date: 2026-02-05
- Package: `pytest`
- Version: `8.4.2`
- Why selected: backend test gate in pre-commit and local verification workflow.
- Source used (`context7`/`deepwiki`/official docs): official PyPI release channel.
- Compatibility notes: all current tests pass locally (`3 passed`).

- Date: 2026-02-06
- Package: `Android Gradle Plugin` + `Kotlin` (mobile scaffold baseline)
- Version: `8.2.2` + `1.9.22` (`mobile/gradle/libs.versions.toml`)
- Why selected: coherent stable baseline from internal Android multi-module skill templates; suitable for initial modular scaffold with Compose.
- Source used (`context7`/`deepwiki`/official docs): `deepwiki` (`android/nowinandroid` module/convention guidance) + local skill templates (`android-development`).
- Compatibility notes: full build not executed in CLI session because local Gradle wrapper/bootstrap is not available yet (`gradle` command missing in environment).

- Date: 2026-02-06
- Package: `Jetpack Compose BOM` + `Navigation Compose` + `Lifecycle Compose`
- Version: `2024.02.00` + `2.8.0` + `2.7.0`
- Why selected: baseline stack for Material 3 UI and Compose navigation in first auth flow slice.
- Source used (`context7`/`deepwiki`/official docs): local skill references (`android-development`, `mobile-android-design`) + `deepwiki` architectural guidance.
- Compatibility notes: first UI modules and auth navigation scaffolded; runtime verification pending Android Studio/Gradle sync on workstation.

- Date: 2026-02-06
- Package: `Retrofit` + Kotlin serialization converter + `OkHttp logging interceptor`
- Version: `2.9.0` + `1.0.0` + `4.12.0`
- Why selected: stable networking baseline for mobile auth API integration (`otp/request`, `otp/verify`) in modular `core:network`.
- Source used (`context7`/`deepwiki`/official docs): local android skill references + `deepwiki` (`android/nowinandroid`) architecture conventions.
- Compatibility notes: integrated in `mobile/core/network`; build/runtime verification pending Android Studio sync because local Gradle wrapper is not bootstrapped in CLI session.

- Date: 2026-02-06
- Package: `kotlinx-serialization-json`
- Version: `1.6.2`
- Why selected: typed JSON parsing for Retrofit DTO layer and backend response handling.
- Source used (`context7`/`deepwiki`/official docs): local Android skill templates and docs references.
- Compatibility notes: used with Kotlin `1.9.22` and serialization plugin in `:core:network`.

- Date: 2026-02-06
- Package: Android Keystore APIs (`android.security.keystore`, `javax.crypto`)
- Version: platform SDK (`compileSdk 34`, no external library)
- Why selected: implement secure token persistence without adding pre-release security dependencies.
- Source used (`context7`/`deepwiki`/official docs): Android platform API baseline and project security-first requirements.
- Compatibility notes: used in `SecureAuthSessionStore` (`app` module) with `AES/GCM`; runtime validation should be performed on emulator/device because CLI build is not available.

- Date: 2026-02-06
- Package: `Gradle Wrapper` + `OpenJDK 17`
- Version: Gradle `8.2.1`, OpenJDK `17.0.18`
- Why selected: ensure reproducible local/CI mobile builds and satisfy Gradle JVM toolchain requirement (`languageVersion=17`).
- Source used (`context7`/`deepwiki`/official docs): Gradle wrapper/docs + local environment validation.
- Compatibility notes: `:app:assembleDebug` now succeeds with `JAVA_HOME=/opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk/Contents/Home`; warnings about SDK XML version mismatch are non-blocking.

- Date: 2026-02-09
- Package: `Dependabot` (GitHub-native dependency update automation)
- Version: n/a (managed GitHub service)
- Why selected: automatic weekly monitoring of fresh stable versions across `pip`, `npm`, `gradle`, Docker and GitHub Actions with low maintenance overhead.
- Source used (`context7`/`deepwiki`/official docs): official GitHub Dependabot docs.
- Compatibility notes: configured in `.github/dependabot.yml`; opens scoped PRs with dependency labels and grouped minor/patch updates.

- Date: 2026-02-09
- Package: `@arvoretech/npm-registry-mcp`
- Version: `1.0.4`
- Why selected: no-key MCP for live npm package/version metadata to keep code examples and dependency decisions current.
- Source used (`context7`/`deepwiki`/official docs): official npm package metadata (`npm view`) and README.
- Compatibility notes: connected globally as MCP server `npm-registry`.

- Date: 2026-02-09
- Package: `mcp-maven-deps`
- Version: `0.1.7`
- Why selected: no-key MCP for checking latest Maven Central versions used by Gradle/KMP dependencies.
- Source used (`context7`/`deepwiki`/official docs): official npm package metadata (`npm view`) and README.
- Compatibility notes: connected globally as MCP server `maven-deps`.
