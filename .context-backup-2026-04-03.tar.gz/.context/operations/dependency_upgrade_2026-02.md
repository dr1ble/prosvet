# Dependency Update Plan - February 2026

## Summary

Comprehensive update of all KMP project dependencies to latest stable versions.

## Updates

| Package | Current | Target | Risk | Migration Actions |
|---------|---------|--------|------|-------------------|
| **Kotlin** | 1.9.22 | **2.3.0** | HIGH | K2 compiler now stable, review breaking changes |
| **Compose Multiplatform** | 1.6.0 | **1.10.0** | MEDIUM | Unified @Preview, Navigation 3 support |
| **Ktor** | 2.3.8 | **3.4.0** | HIGH | Major version bump, uses kotlinx-io |
| **Coil 3** | 3.0.0-alpha10 | **3.3.0** | LOW | Move from alpha to stable |
| **Coroutines** | 1.7.3 | **1.10.2** | LOW | Minor improvements |
| **Serialization** | 1.6.2 | **1.10.0** | MEDIUM | Compatible with Kotlin 2.3 |
| **AndroidX Lifecycle** | 2.8.0 | **2.10.0** | MEDIUM | Full KMP support |
| **Android Gradle Plugin** | 8.2.2 | **9.0.0** | HIGH | Major version, Gradle 9.0 support |

## Migration Strategy

### Phase 1: Core Libraries (Low Risk)
1. ✅ Update Coroutines 1.7.3 → 1.10.2
2. ✅ Update Coil 3.0.0-alpha10 → 3.3.0
3. ✅ Update Serialization 1.6.2 → 1.10.0

### Phase 2: Framework Updates (Medium Risk)
4. ✅ Update Kotlin 1.9.22 → 2.3.0
5. ✅ Update Compose Multiplatform 1.6.0 → 1.10.0
6. ✅ Update AndroidX Lifecycle 2.8.0 → 2.10.0

### Phase 3: Major Version Bumps (High Risk)
7. ✅ Update Ktor 2.3.8 → 3.4.0
8. ✅ Update Android Gradle Plugin 8.2.2 → 9.0.0

## Breaking Changes

### Ktor 3.x
- Uses `kotlinx-io` instead of old IO API
- Some client configuration changes
- **Action**: Test all HTTP calls after update

### Kotlin 2.3.0
- K2 compiler now default and stable
- Improved type inference may reveal hidden issues
- **Action**: Run clean build and fix any new compiler errors

### AGP 9.0.0
- Requires Gradle 9.0+
- New dependency resolution
- **Action**: May need to update `gradle/wrapper/gradle-wrapper.properties`

## Testing Plan

1. Clean build: `./gradlew clean build`
2. Test Desktop: `./gradlew :desktop:run`
3. Test Android: `./gradlew :app:assembleDebug`
4. Test iOS (if Xcode available): `./gradlew :shared:linkDebugFrameworkIosSimulatorArm64`

## Rollback Plan

If issues occur:
1. Git revert changes to `libs.versions.toml`
2. `./gradlew clean`
3. Rebuild

## Sources
- [Kotlin 2.3.0](https://kotlinlang.org/docs/releases.html#release-details)
- [Compose Multiplatform 1.10.0](https://github.com/JetBrains/compose-multiplatform/releases)
- [Ktor 3.4.0](https://ktor.io/docs/releases.html)
- [Coil 3.3.0](https://coil-kt.github.io/coil/)
