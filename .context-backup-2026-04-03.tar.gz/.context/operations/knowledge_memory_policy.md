# Knowledge Memory Policy

## Purpose
- Keep reusable project knowledge in a graph memory for faster retrieval across sessions.
- Preserve `.context/` and source code as the source of truth.

## Storage
- MCP server: `knowledge-memory`
- Storage file: `/Users/npopov/Desktop/ВУЗ/ВКР/Project/.context/operations/kg_memory.jsonl`

## What to Store
- Stable architecture decisions and rationale.
- Domain model relations (e.g., course -> module -> lesson -> screen -> release).
- RBAC constraints and permission rules.
- Invariants and integration contracts between modules.
- Glossary terms and canonical definitions.

## What NOT to Store
- Secrets, tokens, passwords, OTP codes.
- Personal user data or sensitive operational data.
- Temporary debugging notes with no long-term value.
- Facts that are not confirmed by code/docs.

## Entry Quality Rules
- Keep entries atomic: one fact per entry.
- Include source reference (path) and date/version marker.
- Prefer normalized terms over natural-language duplicates.
- If the fact changes, update or delete old memory entries.

## Conflict Resolution
- If memory conflicts with code or `.context/`, trust code and `.context/`.
- After conflict detection, update memory to match the latest confirmed state.

## Recommended Capture Template
- Fact:
- Type: (`decision`, `constraint`, `relation`, `glossary`, `contract`)
- Source:
- Date:
- Version/Scope:

## Bootstrap / Re-seed
- Use project script to (re)build memory from `.context` and core domain entities:
  - `python3 scripts/seed_kg_memory.py --project-root /Users/npopov/Desktop/ВУЗ/ВКР/Project --memory-file .context/operations/kg_memory.jsonl --replace`
- Or use shortcut:
  - `make kg-sync`
- This mode rewrites memory with normalized data (best for cleanup and deterministic startup).
