# MCP Integrations

## Connected in Current Environment
- `context7` (enabled): library docs/examples MCP.
- `deepwiki` (enabled): repository documentation MCP.
- `github` (enabled): GitHub repository MCP.
- `postgres` (enabled): PostgreSQL MCP.
- `openapi` (enabled): OpenAPI MCP server.
- `docker` (enabled): Docker MCP gateway.
- `playwright` (enabled): browser automation + visual UI checks.
- `searxng-public` (enabled): no-key public web search via SearXNG instances.
- `docfork` (enabled): up-to-date library documentation MCP (runs locally via `npx docfork`).
- `codegraphcontext` (enabled): code graph engine; primary usage mode is CLI (`python3 -m codegraphcontext ...`), MCP transport via `python3 -m codegraphcontext mcp start` when needed.
- `knowledge-memory` (enabled): persistent project knowledge graph memory (`npx -y @modelcontextprotocol/server-memory`).
- `npm-registry` (enabled): live npm package metadata/versions.
- `maven-deps` (enabled): Maven/Gradle dependency latest-version lookup.
- `prompts-chat-local` (enabled): local prompts.chat MCP integration.
- `prompts-chat` (enabled, URL): remote prompts.chat MCP endpoint.

## How We Use MCP in This Project
- For every new dependency or framework update:
  - first query `context7`,
  - then verify project/repo specifics in `deepwiki`.
- If MCP does not provide enough detail, fallback to official docs/changelog.
- For cross-session project knowledge:
  - keep source-of-truth in code + `.context`,
  - mirror stable, sanitized facts to `knowledge-memory` for fast retrieval.
- For code graph/context analysis:
  - default to CodeGraphContext CLI (`index`, `watch`, and analysis commands),
  - use MCP wrapper calls only when direct CLI execution is unavailable.

## Recommended Additional MCP Connections
## Post-Setup Notes
- `postgres` is currently configured with local DSN:
  - `postgresql://localhost:5432/postgres`
  - update this DSN if your DB host/port/name differs.
- `sentry` MCP was intentionally removed for the current stage (not needed during local-first setup).
- `brave-search` MCP is intentionally not used in this project baseline because it requires API key setup.
- For no-key internet search, use `searxng-public`.
- `docfork` supports API key/OAuth modes; current local setup is stdio launch via `npx -y docfork`.
- `knowledge-memory` stores records in:
  - `/Users/npopov/Desktop/ВУЗ/ВКР/Project/.context/operations/kg_memory.jsonl`
- Memory safety rules:
  - never store secrets, credentials, tokens, OTP, or personal user data,
  - store only project-level facts, constraints, and architectural decisions with source references.
- Some servers can require local runtime/tools (`npx`, `docker`) to be installed and available in PATH.
