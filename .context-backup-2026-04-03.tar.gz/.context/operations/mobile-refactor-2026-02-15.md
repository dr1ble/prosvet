# Mobile refactor log — 2026-02-15

## Scope
Reviewed and applied safe refactors in `mobile/` with behavior preservation.

## Changes
1. `mobile/feature/home/impl/HomeRoute.kt`
   - Extracted duplicated snackbar+dismiss logic into `showAndDismissIfNeeded(...)`.
   - Cached single `AuthRepository` instance instead of repeated `koin.get<AuthRepository>()` calls.

2. `mobile/feature/home/impl/catalog/CatalogViewModel.kt`
   - Reduced duplication of loading/error state updates via `setLoading()` and `setError(...)` helpers.

3. `mobile/feature/home/impl/profile/ProfileViewModel.kt`
   - Reduced duplication of submit/error state updates via `setSubmitting()` and `setError(...)` helpers.

4. `mobile/feature/auth/impl/AuthViewModel.kt`
   - Removed unused import (`PhoneNumberFormatter`).

## Notes
- Attempted Builder `context_builder` review/plan flow, but MCP tool failed due missing Claude CLI in environment.
- Attempted Gradle verification (`./gradlew :feature:home:impl:compileKotlinMetadata :feature:auth:impl:compileKotlinMetadata`) but sandbox escalation was rejected.
