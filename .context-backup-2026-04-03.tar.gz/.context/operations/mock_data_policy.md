# Mock Data Policy

## Domain Focus: Digital Literacy for Pensioners

**ALL** mock data, seed data, test fixtures, and sample content MUST be related to **digital literacy training for pensioners** (цифровая грамотность пенсионеров).

## Prohibited Topics

The following topics are **NOT ALLOWED** in mock data:

- ❌ Warehouse/logistics (РЦ, Склад, приемка, комплектовщики, смены)
- ❌ Retail operations (магазины, склады, товарооборот)
- ❌ Manufacturing (производство, цеха, станки)
- ❌ Corporate HR (сотрудники, отделы, должности компаний)
- ❌ Any B2B/enterprise operations unrelated to pensioner education

## Approved Topics

Mock data SHOULD focus on:

- ✅ Digital literacy courses (цифровая грамотность, смартфон, мессенджеры)
- ✅ Online services for pensioners (Госуслуги, онлайн-банкинг, телемедицина)
- ✅ Safety and security (безопасность в интернете, мошенничество)
- ✅ Daily life services (ЖКХ онлайн, запись к врачу)
- ✅ Communication tools (видеосвязь, социальные сети)
- ✅ Educational groups (клубы, группы по интересам, курсы)

## Naming Conventions

### Groups (Learning Groups)

**APPROVED pattern:**
```
Группа "[Название]" — [Уровень/Время]
```

**Examples:**
- Группа "Цифровой Старт" — Утро
- Группа "Цифровой Старт" — Вечер
- Группа "Серебряный Возраст" — Базовый
- Группа "Серебряный Возраст" — Продвинутый
- Группа "Активное Долголетие" — Утро
- Группа "Мудрость Поколений" — Вечер

**PROHIBITED:**
- ❌ РЦ Запад — Приемка
- ❌ Склад Юг — Смена А
- ❌ Клуб Северный (географические названия без контекста образования)

### Courses

**APPROVED topics:**
- Смартфон: базовые действия
- Мессенджеры и видеосвязь
- Онлайн-банкинг без ошибок
- Госуслуги в повседневной жизни
- Безопасность в интернете
- Полезные сервисы для дома и здоровья
- Телемедицина: запись и консультации

### Users

**APPROVED pattern:**
- Display names: реалистичные имена пенсионеров (Вера, Галина, Николай, Татьяна и т.д.)
- Logins: `demo_lit_user_XX`, `demo_lit_admin`, `demo_lit_mod`

## Files Location

Mock/seed data files are located in:

- `backend/scripts/` — seed scripts for database
- `backend/tests/` — test fixtures
- `progress-snapshot.md` — UI mock snapshots (reference only)

## Current Mock Data Files

| File | Purpose | Status |
|------|---------|--------|
| `backend/scripts/digital_literacy_demo_seed.py` | Demo users, groups, courses | ✅ Compliant |
| `backend/scripts/catalog_mock_data.py` | Course catalog samples | ✅ Compliant |
| `backend/scripts/course_builder_mocks.py` | Course builder test data | ✅ Compliant |
| `backend/scripts/progress_mocks.py` | Progress generation | ✅ Compliant |
| `progress-snapshot.md` | UI snapshot reference | ✅ Updated (2026-04-02) |

## Enforcement

Before adding new mock data:

1. **Review**: Does this content align with digital literacy for pensioners?
2. **Check**: Are there any prohibited topics (warehouse, logistics, corporate)?
3. **Validate**: Would this content make sense in a senior education context?

If in doubt, consult `.context/planning/current_focus.md` or ask the team.

## Change Log

### 2026-04-02: Warehouse Data Cleanup

**Removed:**
- All warehouse/logistics group names from `progress-snapshot.md`
- Replaced "РЦ", "Склад" with education-focused group names
- Updated `digital_literacy_demo_seed.py` group naming

**Before:**
```
- РЦ Запад — Приемка
- РЦ Восток — Комплектовщики
- Склад Юг — Смена А/Б
- Склад Север — Смена А/Б
```

**After:**
```
- Группа "Цифровой Старт" — Продвинутый
- Группа "Серебряный Возраст" — Базовый
- Группа "Активное Долголетие" — Утро/Вечер
- Группа "Мудрость Поколений" — Утро/Вечер
```

**Rationale:** Warehouse/logistics terminology is completely inappropriate for a digital literacy training platform targeting pensioners. All mock data must reflect the educational domain.
