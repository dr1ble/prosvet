# Local Runbook

## Purpose
- Standardize local startup flow for fast onboarding and repeatable runs.

## Prerequisites
- Docker Desktop running.
- Git installed.
- `npx` available (for some MCP servers/tools).

## Planned Local Stack (MVP foundation)
- `postgres`
- `backend-api`
- `web-admin` (started locally via Node.js)
- optional local object storage for media (later)

## Startup Flow
1. Copy env template:
   - `cp .env.example .env`
2. Start local stack with unified script:
   - `./run`
   - or background mode: `make run-bg`
3. Check backend health:
   - `curl http://localhost:8000/api/v1/health`
4. Run one-command diagnostics:
   - `make doctor`
   - for background mode: `make status` and `make dev-logs`
5. Open web admin:
   - `http://localhost:3000`
6. Sign in:
   - open `/auth`
   - use `APP_ADMIN_LOGIN` / `APP_ADMIN_PASSWORD` from `.env`.
7. Mobile:
   - open `mobile/` in Android Studio and continue scaffold from module placeholders.

## `run` Script Notes
- `./run` starts:
  - PostgreSQL (docker compose),
  - backend (`uvicorn --reload`),
  - web-admin (`next dev`),
  - `codegraphcontext watch` for automatic graph updates,
  - knowledge-memory auto-sync (`scripts/seed_kg_memory.py`) when `.context`/`Claude.md` changed.
- Optional overrides:
  - `CGC_WATCH=0 ./run` to disable codegraph watcher.
  - `CGC_WATCH_PATH=/absolute/path ./run` to watch another directory.
  - `KG_MEMORY_SYNC=0 ./run` to disable memory auto-sync.
  - `KG_MEMORY_SYNC_MODE=force ./run` to force full memory re-seed on startup.
  - `KG_MEMORY_FILE=/absolute/path/file.jsonl ./run` to use custom memory storage file.

## Background Mode
- Start in background: `make run-bg`
- Check status: `make status`
- Tail logs: `make dev-logs`
- Stop stack: `make stop`
- Restart stack: `make restart`
- Internals:
  - PID file: `.run/run.pid`
  - Combined logs: `.run/dev.log`
  - CodeGraph watch log: `.run/codegraph-watch.log`
  - Log rotation on start is enabled for both files.

## CodeGraphContext CLI (Default)
- Use CLI as the default way to work with code graph context:
  - `python3 -m codegraphcontext index /Users/npopov/Desktop/ВУЗ/ВКР/Project`
  - `python3 -m codegraphcontext watch /Users/npopov/Desktop/ВУЗ/ВКР/Project`
  - `python3 -m codegraphcontext mcp start` (only when MCP transport is needed by tools)
- Policy:
  - CLI first for context discovery and impact analysis.
  - MCP wrapper calls are fallback-only.
- Make shortcuts:
  - `make cgc-index` (optional override: `CGC_PATH=/abs/path make cgc-index`)
  - `make cgc-watch`
  - `make cgc-list`
  - `make cgc-mcp`

## Manual Memory Sync
- `make kg-sync` - rebuild `knowledge-memory` graph from project context and domain seed.

## Health Checks
- DB reachable.
- Backend health endpoint returns OK.
- Web admin opens and can call API.
- Mobile module structure is present and ready for implementation.

## Dependency Freshness Checks
- Run local freshness check:
  - `make deps-check`
- Automation:
  - Dependabot config lives in `.github/dependabot.yml` and opens weekly update PRs.

## Troubleshooting
- If DB connection fails:
  - verify port mapping and env vars.
  - backend tests may default to `localhost:5433`; if your local Postgres is on `5432`, run tests with:
    - `APP_DATABASE_URL='postgresql+psycopg://app:app@127.0.0.1:5432/app' TEST_DATABASE_URL='postgresql+psycopg://app:app@127.0.0.1:5432/app' PYTHONPATH=. pytest tests/`
- If migrations fail:
  - check migration ordering and DB state.
- If login returns `500` with `relation "users" does not exist`:
  - run stack using `./run` (it now auto-repairs broken public schema and reapplies migrations).
  - verify with `make doctor`.
- If CORS issues appear:
  - verify backend allowed origins config.

## Notes
- Keep this runbook updated when commands or ports change.
