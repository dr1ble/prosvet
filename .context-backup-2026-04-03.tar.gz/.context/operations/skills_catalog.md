# Skills Catalog

## Purpose
- Track active and custom skills used for this project.
- Keep startup context predictable across sessions.

## Built-in Skills (session-level)
- `pdf`
- `skill-creator`
- `skill-installer`

## Custom Skills Installed in `$CODEX_HOME/skills`
- `module-scaffold`
  - Path: `/Users/npopov/.codex/skills/module-scaffold/SKILL.md`
  - Use for: creating or refactoring modular structure for backend/web/mobile.
- `dependency-check`
  - Path: `/Users/npopov/.codex/skills/dependency-check/SKILL.md`
  - Use for: dependency upgrades with latest stable versions and best-practice verification.
- `context-log`
  - Path: `/Users/npopov/.codex/skills/context-log/SKILL.md`
  - Use for: logging non-trivial decisions and progress into `.context/`.
- `codegraphcontext-first`
  - Path: `/Users/npopov/.codex/skills/codegraphcontext-first/SKILL.md`
  - Use for: graph-first code discovery and impact analysis; fallback to `rg` only when graph data is unavailable.

## Notes
- New skills may require a new session to appear in skill discovery list.
- If a skill changes project conventions, update `Claude.md` and relevant `.context/*.md` files.
