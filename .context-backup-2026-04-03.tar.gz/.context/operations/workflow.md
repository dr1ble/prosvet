# Workflow Standards

## Purpose
- Keep day-to-day execution consistent and predictable.

## Branching
- Use neutral branch names without AI-specific prefixes.
- Naming pattern:
  - `feature/<short-topic>`
  - `fix/<short-topic>`
  - `chore/<short-topic>`

## Commit Style
- Use concise conventional commit style:
  - `feat: ...`
  - `fix: ...`
  - `refactor: ...`
  - `docs: ...`
  - `chore: ...`
- Keep one logical change per commit.

## PR Checklist (when using PR workflow)
- Problem statement is clear.
- Scope matches the task (no unrelated changes).
- Tests/lint/type-check status included.
- `.context/` updates included for non-trivial decisions.
- PR body is filled using `.github/pull_request_template.md`.

## Issue/PR Templates
- Use issue templates from `.github/ISSUE_TEMPLATE/`:
  - `bug_report.md`
  - `feature_request.md`
  - `tech_task.md`
- Use PR template from `.github/pull_request_template.md`.

## Task Execution Checklist
1. Read `.context/README.md`.
2. Confirm target module and affected contracts.
3. For non-trivial cross-file tasks, run `codegraphcontext` via CLI first (`python3 -m codegraphcontext ...`), then open only relevant files.
4. Implement minimal safe change.
5. Validate with tests/checks.
6. Log decision and next step in `.context/`.

## Code Context Discovery (Mandatory)
- Primary mode: `CodeGraphContext CLI`.
- Preferred commands:
  - `python3 -m codegraphcontext index <path>`
  - `python3 -m codegraphcontext watch <path>`
  - `python3 -m codegraphcontext mcp start` (when MCP transport is required)
- Fallback order:
  1. CodeGraphContext CLI
  2. CodeGraphContext MCP wrapper (only if CLI cannot be used)
  3. `rg` / direct file scans

## Local Pre-Commit Gate
- Hook install command: `make install-hooks`
- Runs automatically on commit:
  - `lint-staged` + `prettier` for staged files under `web/`
  - `ruff` for staged Python files under `backend/`
  - `pytest` in **smart mode** for backend changes:
    - runs on critical backend paths or large backend change sets,
    - skipped for small non-critical backend edits.
    - override per commit via `PRECOMMIT_PYTEST_MODE=always|never|smart`.
  - staged diff guard for `placeholder|TODO|FIXME`

## Done Criteria
- Code and tests are updated.
- Architecture boundaries are respected.
- Relevant `.context/` files are current.
