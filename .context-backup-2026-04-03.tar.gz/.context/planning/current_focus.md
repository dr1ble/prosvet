# Current Focus

## Sprint Goal
- Sprint 1: Auth/dashboard shell + permission-aware navigation. **In progress** - базовый функционал не завершён, UX требует доработки.

## Progress Snapshot

### Completed
- Repository scaffold for `backend`, `web-admin`, `mobile`
- Docker Compose setup (PostgreSQL + backend)
- Auth: login/password, optional QR login, session lifecycle
- Catalog: courses, releases, screen storage
- Simulation: builder, drafts, transitions, hints
- Web-admin: auth, dashboard, catalog workspace, simulation builder
- Mobile: KMP migration (Android/Desktop/iOS), auth, course list, lesson playback
- Quality gates: ruff, pytest, prettier, lint-staged, git hooks
- [NEW] Lesson Flow Audit: Redesign to "Guided Learning Path" (Video -> Simulation -> Quiz -> Cheat Sheet)
- [NEW] Simulation Editor Redesign (Figma-like):
  - Phase 1-3: React Flow canvas, screen nodes, transitions, presets, media
  - Phase 4: Hotspot drawing, selection, editing
  - Phase 5-6: Save/load draft, export JSON, library integration

### Integration Status (2026-02-11)
| Check | Status |
|-------|--------|
| Backend tests | ✅ 21 passed |
| Backend lint | ✅ ruff clean |
| Web-admin lint | ⚠️ 7 warnings (img → Image) |
| Web-admin type-check | ✅ No errors |
| PostgreSQL | ✅ Up 29h, healthy |
| Backend API | ✅ Running :8000 |
| Web-admin | ✅ Running :3000 |

### In Progress (Sprint 1)
- Доработка базового функционала
- Улучшение UX
- [NEW] Course Builder (no-code editor) — MVP+ расширения реализованы (структура, контент, квизы, симуляции, preview, publish)
- [NEW] Groups & Assignment MVP-1 implementation started (groups, memberships, group course assignments)

### Completed (Sprint 1)
- [x] DB-driven RBAC policy engine — backend module + admin UI + migration 0016
- [x] DataState component rollout (dashboard, catalog error handling)

### Known Issues
- [ ] Fragmented course creation: wizard + simulation editor are separate tools
- [ ] No visual course structure editor

## Near-Term Next
1. Stabilization: использовать `./run` + `make doctor` как стандарт запуска/диагностики
2. Завершить Sprint 1 — remaining: audit logs, global search, E2E smoke coverage
3. Sprint 2: analytics, offline mode, AI features

## Risks
- Admin onboarding still simplified (bootstrap by env credentials)
- Need strict boundary discipline for modular monolith

## Update Rule
- Keep this file short.
- Update priorities whenever focus shifts.
