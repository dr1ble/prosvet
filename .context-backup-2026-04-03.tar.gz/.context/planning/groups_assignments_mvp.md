# Groups & Assignments MVP Plan

Date: 2026-04-01
Status: Approved for implementation

## Goal
- Deliver MVP-1 for `Groups and Assignment` in Web Admin.
- Scope: learning groups, group membership, and course assignment to groups.

## Included (MVP-1)
- Group CRUD:
  - create, list, update, archive, restore.
- Membership management:
  - add/remove users in a group via bulk replacement endpoint.
- Group course assignments:
  - create, list, update assignment status/schedule.
- Dashboard navigation:
  - `Groups and Assignment` tile opens `/groups`.

## Excluded (MVP-2)
- Progress analytics widgets.
- Global search integration.

## MVP-2 Extension (in progress)
- Individual assignment targets for selected users:
  - `group_course_assignment_target_users` table.
  - `target_user_ids` in assignment create/update payload.
  - assignment response includes `target_user_ids` and `target_users_count`.
  - UI supports selecting individual users when creating assignment.

## Backend Contract (planned)
- `GET /api/v1/groups`
- `POST /api/v1/groups`
- `PATCH /api/v1/groups/{group_id}`
- `POST /api/v1/groups/{group_id}/archive`
- `POST /api/v1/groups/{group_id}/restore`
- `GET /api/v1/groups/{group_id}/members`
- `PUT /api/v1/groups/{group_id}/members`
- `GET /api/v1/groups/{group_id}/assignments`
- `POST /api/v1/groups/{group_id}/assignments`
- `PATCH /api/v1/groups/{group_id}/assignments/{assignment_id}`

## RBAC
- Read endpoints: `groups.view`
- Write endpoints: `groups.manage`

## Data Model (MVP-1)
- `groups`
- `group_memberships`
- `group_course_assignments`

## UX Notes
- Use existing web-admin visual language (same style as `catalog`).
- Keep interactions simple and operational (task-first).
- Hide unavailable actions based on permissions.
