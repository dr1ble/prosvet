# Interview Log

## Source
- Requirements file: `funcs_req.pdf`
- Date: 2026-02-05

## Extracted Functional Scope
- Platform consists of 2 parts:
  - Web platform for Administrator, Methodologist, Moderator.
  - Mobile app for pensioners and other end users.
- Web modules:
  - Course and simulation constructor.
  - LMS with hierarchy and moderation statuses.
  - Analytics dashboard.
  - User admin and QR access generation.
  - Fast content refresh mechanism for simulation screens based on APK updates.
- Mobile modules:
  - Hybrid lesson player: video, simulation, summary.
  - Smart hints, favorites, TTS.
  - Cybersecurity trainer with dialog scenarios.
  - Assistant and navigation (idle hints, voice search, glossary).
  - Accessibility/adaptation (passwordless login, tremor filter, UI modes).
  - Gamification and offline mode.

## Open Decisions (Interview)
- [x] Tech stack finalization (backend and web framework concrete choice).
- [x] MVP scope vs phase 2 scope.
- [x] APK-to-screens pipeline design for fast course updates.
- [x] Mobile auth flow details (phone/OTP/QR).
- [x] QR lifecycle and issuance policy.
- [x] Privacy-first identity model (minimum personal data policy).
- [x] Self-authorization flow details (phone or email based).
- [x] Cross-platform modular architecture principle.
- [x] Summary generation model.
- [x] RBAC granularity.
- [x] Offline data and sync strategy.
- [x] SOS integration channel.
- [x] Security/compliance constraints.
- [x] Deployment target.
- [x] AI features in MVP.
- [x] Dependency freshness and best-practice source policy.

## Answers
- 2026-02-05, Q1 (tech stack direction):
  - Backend: priority is rapid delivery and easy future AI integration.
  - Web admin: wants modern stack and high-quality UI.
  - Mobile: Kotlin + Compose Multiplatform foundation, Android first; modular architecture (`api/impl`) required.
  - Database: PostgreSQL.
  - Infrastructure: Docker containers expected, details to be defined.
- 2026-02-05, Q1 confirmation:
  - Confirmed backend: `FastAPI`.
  - Confirmed web admin: `Next.js + React + TypeScript`.
  - Confirmed mobile direction: `Kotlin Compose Multiplatform`, Android first.
  - Confirmed database: `PostgreSQL`.
  - Confirmed infra baseline: `Docker`/`Docker Compose`.
- 2026-02-05, additional requirement:
  - Web platform must support fast course updates via APK-related screen refresh workflow.
  - Goal: quickly refresh all app screens used in training simulations when mobile app changes.
  - Open risk: APK does not guarantee direct extraction of all final runtime screens; may require emulator-based capture pipeline.
- 2026-02-05, APK update pipeline decision:
  - Confirmed option: hybrid.
  - MVP: methodist uploads prepared screenshots archive (ZIP) and maps to lesson steps.
  - Phase 2: add automated screen extraction pipeline from uploaded APK (emulator/device farm automation).
- 2026-02-05, auth concern:
  - User prefers minimizing sensitive personal data collection.
  - Additional constraint: access flow must not depend on curator as the only access issuer.
  - Note: early "no mandatory phone" direction was superseded by final decision to use phone OTP in MVP.
- 2026-02-05, auth flow decision:
  - Entry options in MVP:
    - QR authorization from curator.
    - Self-authorization by end user.
  - Note: this intermediate decision was superseded by final phone-based self-auth decision.
- 2026-02-05, analytics-preserving auth recommendation (pending confirmation):
  - Superseded by confirmed MVP auth model: `phone + SMS OTP` and optional curator QR.
- 2026-02-05, auth revision request:
  - User considers adding contact-based authorization in MVP.
  - Candidate channels under consideration: phone number (`SMS OTP`) or email (`magic link/OTP`).
- 2026-02-05, auth final decision for MVP:
  - Self-authorization: phone number + SMS OTP.
  - Alternative authorization: curator-issued QR.
  - Email-based authorization moved out of MVP.
  - Remaining auth params to define:
    - OTP lifetime and retry limits.
    - QR token lifetime, one-time/reusable policy.
- 2026-02-05, auth security params confirmation:
  - OTP token lifetime: 5 minutes.
  - OTP retries: 5 attempts.
  - Temporary block after retries exceeded: 15 minutes.
  - QR token policy: one-time token, invalidated on first successful login.
  - QR token lifetime: 24 hours.
- 2026-02-05, scope decision:
  - Analytics moved from MVP to Phase 2.
  - MVP includes:
    - Web: lesson constructor, LMS hierarchy, moderation statuses, roles, ZIP-based screen refresh import.
    - Mobile: OTP/QR auth, lesson playback flow, hints, favorites, accessibility basics.
    - Infra: Docker Compose baseline.
  - Phase 2 includes:
    - Analytics module,
    - APK automated screen extraction,
    - Cybersecurity trainer,
    - Voice search and TTS,
    - SOS notifications,
    - Gamification,
    - Full offline sync,
    - AI-driven enhancements.
- 2026-02-05, architecture principle:
  - Entire system must be modular and extensible for fast feature additions.
  - Mandatory modular decomposition:
    - Backend: domain modules with clear API boundaries.
    - Web admin: feature-based modular frontend architecture.
    - Mobile: Compose Multiplatform modules with `api/impl` separation.
- 2026-02-05, summary model decision:
  - MVP: template-based summary generation with auto-filled dynamic blocks and manual template control by methodist.
  - Phase 2: fully automatic summary generation with post-generation manual correction.
- 2026-02-05, RBAC decision:
  - Roles:
    - `Administrator`: user and role management, platform settings, access control.
    - `Methodologist`: create/edit courses, lessons, simulations, summary templates, submit for moderation.
    - `Moderator`: review content, approve/reject publication, archive management.
    - `User`: mobile-only role, consume training content, manage favorites, track own progress.
  - Publication policy:
    - Methodologist cannot publish directly.
    - Publication requires moderator approval.
- 2026-02-05, offline strategy decision:
  - MVP: online-only mode (no offline cache/sync).
  - Phase 2:
    - offline lesson materials cache,
    - local progress buffering,
    - deferred synchronization on reconnect,
    - progress conflict rule: last write wins.
- 2026-02-05, security baseline decision for MVP:
  - HTTPS-only transport.
  - JWT access + refresh token pair.
  - Phone field protected (hash and/or encryption at rest).
  - Admin-side audit trail enabled (administrator/methodologist/moderator actions).
  - Rate limiting for OTP and login endpoints.
  - Daily PostgreSQL backups.
- 2026-02-05, deployment decision:
  - Current deployment target: local environment only.
  - Production/cloud/on-prem rollout postponed to later phase.
- 2026-02-05, AI scope decision:
  - No end-user AI features in MVP.
  - AI functionality planned for Phase 2.
  - MVP must keep extension points for future AI integration (separate module boundary and events-ready architecture).
- 2026-02-05, SOS channel decision:
  - Phase 2 priority channels:
    - Telegram notification.
    - Push notification to curator application.
- 2026-02-05, personal data policy decision:
  - Store minimal profile data in MVP:
    - phone number (for OTP auth),
    - role,
    - display name (optional),
    - date of birth (for analytics segmentation).
  - Do not store high-sensitivity identifiers (passport data, residence address).
- 2026-02-05, dependency policy decision:
  - Always use актуальные стабильные версии библиотек.
  - Best practices for library usage should be checked via MCP:
    - first `context7`,
    - then `deepwiki`,
    - fallback to official docs when needed.
- 2026-02-05, context continuity decision:
  - For non-trivial tasks, decisions and outcomes must be logged in `.context/`.
  - Goal: preserve resumable project context and reduce restart cost after pauses.
- 2026-02-05, MCP decision update:
  - `sentry` MCP removed as not required for current local-first stage.
  - Active MCP set for now: `context7`, `deepwiki`, `github`, `postgres`, `openapi`, `docker`.
- 2026-02-05, custom skills setup:
  - Added custom skills in `$CODEX_HOME/skills`:
    - `module-scaffold`,
    - `dependency-check`,
    - `context-log`.
  - Added project skills registry file: `.context/operations/skills_catalog.md`.
- 2026-02-06, context structure refactor:
  - Reorganized `.context/` into logical subdirectories:
    - `planning/`,
    - `architecture/`,
    - `product/`,
    - `operations/`.
  - Added `.context/README.md` as a startup index and reading order.
  - Updated project references and custom skill paths to new context file locations.
- 2026-02-06, operations and planning boost:
  - Added `.context/operations/workflow.md` with branch/commit/PR/task standards.
  - Added `.context/planning/current_focus.md` for active sprint priorities.
  - Added `.context/operations/runbook_local.md` for local startup and troubleshooting.
- 2026-02-06, naming convention update:
  - Branch naming must stay neutral (no AI-related prefixes).
  - Preferred patterns: `feature/*`, `fix/*`, `chore/*`.
- 2026-02-06, delivery standardization:
  - Added GitHub templates:
    - `.github/pull_request_template.md`,
    - `.github/ISSUE_TEMPLATE/bug_report.md`,
    - `.github/ISSUE_TEMPLATE/feature_request.md`,
    - `.github/ISSUE_TEMPLATE/tech_task.md`,
    - `.github/ISSUE_TEMPLATE/config.yml`.
  - Workflow updated to require template-based issue/PR descriptions.
- 2026-02-06, documentation completeness update:
  - Added repository entrypoint: `README.md`.
  - Added documentation quality tracker: `.context/operations/documentation_status.md`.
- 2026-02-06, implementation kickoff:
  - Created initial repository scaffold:
    - `backend/` modular FastAPI skeleton,
    - `web-admin/` Next.js structural scaffold,
    - `mobile/` CMP module scaffold.
  - Added local runtime baseline:
    - root `docker-compose.yml` with `postgres` + `backend`,
    - root `.env.example`,
    - root `Makefile`.
  - Added backend auth API stubs:
    - `POST /api/v1/auth/otp/request`,
    - `POST /api/v1/auth/otp/verify`,
    - `POST /api/v1/auth/qr/activate`.
  - Updated runbook with concrete startup commands.
  - Validation note:
    - Python syntax check passed via `compileall`.
    - `docker` CLI is unavailable in current shell, so compose runtime validation is pending local environment check.

## Confirmed Stack Baseline
- Backend: `FastAPI` + `SQLAlchemy` + `Alembic` + `PostgreSQL` (fast iteration + simple AI integration path).
- Web admin: `Next.js (React + TypeScript)` + component system and design tokens.
- Mobile: `Kotlin Compose Multiplatform` with Android target in MVP and feature modules (`api/impl`).
- Infrastructure: `Docker Compose` for MVP, CI/CD and orchestration phased later.

## Web Admin Useflow Interview (2026-02-08)

### Round 1: Roles, goals, entry flow
- Roles confirmed:
  - `Админ` — полный доступ.
  - `Методолог` — создание и изменение курсов/контента.
  - `Модератор` — одобрение курсов, контроль групп.
  - `Куратор` — добавление пользователей в группы, отслеживание прогресса.
- Product focus:
  - KPI MVP: сократить время обучения и ускорить публикацию актуального контента.
  - Business process: полный цикл от создания курса до прохождения и анализа.
- UX baseline:
  - Первый экран: авторизация.
  - После входа: общий дашборд с плитками функционала.
- MVP modules:
  - `Каталог`, `Релизы`, `Пользователи/группы`, `Прогресс/статистика`.
  - `Уведомления` исключены из MVP.
- Release flow:
  - `draft -> review -> approved -> published`.
- Critical confirmations (publish/archive/delete/rollback):
  - признаны критичными, но подтверждения можно вынести из MVP.

### Round 2: Content and group model
- Group model:
  - Группа = учебный класс.
  - Пользователь может быть в нескольких группах.
  - Пользователь может быть без группы.
- Group management:
  - Группы могут создавать и модератор, и куратор.
- Assignment model:
  - Назначение курсов доступно как на группу, так и на конкретного пользователя.
- Content hierarchy:
  - `Курс -> Модули -> Уроки -> Экраны`.
- Course fields:
  - `slug` необязателен.
  - Обложка опциональна (может быть placeholder).
- Release policy:
  - Релиз рассматривается как версия контента (с уточнением привязки к версии приложения).
  - Релиз можно редактировать.
- Phase 2 TODO:
  - Автосохранение черновиков для методолога.

### Open clarifications from Round 2
- Нужно формально зафиксировать совместимость релиза с версиями приложения:
  - `app_min_version`,
  - `app_target_version` или `app_version_range`.
- Нужно решить финальную политику редактирования после публикации:
  - разрешить редактировать `published` релиз,
  - или зафиксировать immutable `published` и править только через новый релиз.

### Round 3: Progress, dashboard and MVP priority
- Release editing policy:
  - принято `A`: опубликованный релиз можно редактировать.
- Learner progress model:
  - прогресс считать по завершённым урокам.
- Dashboard modules after login (tiles):
  - `Каталог`,
  - `Релизы на модерации`,
  - `Группы`,
  - `Прогресс`,
  - `Пользователи`.
- Search:
  - глобальный поиск в MVP нужен.
- Audit:
  - аудит пока только в БД (без отдельного UI в MVP).
- Scope priority update:
  - главный фокус MVP: полный инструментарий создания курса (authoring-first).
  - расширенная аналитика и продвинутая отчётность переносится после authoring-блока.

### Open clarifications after Round 3
- Уточнить совместимость релиза с приложением:
  - хранить `app_min_version` + `app_target_version`,
  - или хранить `app_version_range`.
- Зафиксировать детализацию метрик для MVP-дашбордов:
  - какие обязательные виджеты для куратора и модератора в первой итерации.

### Round 4: Authoring details and permissions
- Lesson fields:
  - базовый набор обязательных полей подтвержден (title/type/estimated_duration/pass_score).
- Screen types in MVP:
  - сразу включать расширенный набор: `video`, `simulation`, `quiz`, `summary` (в дополнение к базовым).
- Reordering UX:
  - drag-and-drop для модулей/уроков/экранов нужен в MVP.
- Release-app compatibility:
  - принято хранить `app_version_range` (вариант B).
- Published release editing:
  - разрешить редактирование для `методолог`, `куратор`, `модератор`, `админ`.
  - требуется механизм управления правами действий (action-level permissions).
- Deletion policy:
  - только мягкое удаление (`archive`/`soft delete`) в MVP.
- Priority reinforcement:
  - основной фокус MVP — полный инструментарий создания курса (authoring-first),
  - аналитика после завершения authoring-функционала.

### Open clarifications after Round 4
- Утвердить минимальный набор обязательных виджетов аналитики для MVP (после authoring).

### Round 5: RBAC model
- Key decision:
  - не хардкодить права ролей в коде.
  - использовать гибкую permission-политику (DB-driven).
- Direction:
  - action-level permissions configurable from admin side,
  - роль становится шаблоном, а не жесткой матрицей в коде.

### Round 6: RBAC policy constraints (MVP)
- User-role model:
  - один пользователь = одна активная роль (multiple roles disabled).
- Overrides:
  - персональные override-права не нужны в MVP.
- Permission scopes:
  - `global`, `group`, `own`.
- Conflict rule:
  - `deny` has priority over `allow`.
- Policy management:
  - менять политики прав может только `admin`.
- Audit:
  - каждое изменение политики прав логируется в БД.
- UX of denied actions:
  - запрещенные действия скрываются (не показывать disabled).
- Policy versioning:
  - versioning/rollback policy UI не нужен в MVP.

### Round 7: Module schema confirmation
- Module schema confirmed:
  - required: `title`, `order_index`.
  - optional: `description`, `status`.

### Round 8: Lesson linkage and quiz schema
- Course isolation:
  - курс считается изолированной единицей контента.
  - контент не переиспользуется между курсами в MVP.
- Lesson linkage:
  - урок принадлежит одному модулю (many-to-one lesson -> module).
- Quiz schema:
  - `passing_score` и `attempt_limit` — optional.
  - `shuffle_questions` — optional.
  - `time_limit` — required in MVP.

### Round 9: Analytics scope finalization
- Analytics decision:
  - аналитика полностью переносится в Phase 2.
- MVP implication:
  - в MVP остаются только операционные экраны, критичные для authoring и назначения обучения,
  - без отдельного продвинутого аналитического модуля.
