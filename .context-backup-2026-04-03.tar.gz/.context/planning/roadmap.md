# Roadmap

## Status Legend
- `[ ]` not started
- `[~]` in progress
- `[x]` completed

## Phase 0: Foundation (Current)
- [x] Initialize mono-repo structure for `backend`, `web-admin`, `mobile`.
- [x] Configure modular scaffolding:
  - backend domain modules,
  - web feature modules,
  - mobile `api/impl` modules.
- [x] Create local `docker-compose.yml` (backend + postgres + object storage if needed).
- [ ] Define base CI checks (lint, tests, type-check).
- [x] Create initial `.env.example` and secret handling policy.
- [x] Finalize concrete local run commands in `.context/operations/runbook_local.md`.

## Phase 1: MVP

### 1. Authentication and Access
- [~] Implement login/password auth: login, refresh token, logout.
- [~] Implement optional one-time curator QR login.
- [~] Implement auth security limits:
  - login rate limiting,
  - QR one-time, 24h TTL.

### 2. RBAC and Admin Foundation
- [~] Roles: `Administrator`, `Methodologist`, `Moderator`, `User`.
- [ ] Enforce publish flow: Methodologist -> Moderator approval -> Published.
- [ ] Replace hardcoded role rules with DB-driven RBAC policy engine.
- [ ] Implement policy management UI (admin-only).
- [ ] Implement audit logs for admin-side actions and policy changes.

### 3. Content Authoring (Web)
- [ ] Category/Course/Module/Lesson hierarchy.
- [~] Basic course/release create flow in web-admin.
- [~] Course Builder (no-code editor) — see `.context/feature/course-builder.md`
  - [x] Phase 0: Foundation (bulk API, store, types)
  - [x] Phase 1: MVP — visual structure editor (sidebar + drag & drop)
  - [x] Phase 2: Inline content editors (text, video, cheat sheet)
  - [x] Phase 3: Quiz constructor
  - [x] Phase 4: Simulation integration (embedded React Flow)
  - [x] Phase 5: Live preview (mobile frame)
  - [x] Phase 6: Publishing with validation
- [ ] Lesson constructor with screen types: `video`, `simulation`, `quiz`, `summary`.
- [~] Simulation builder:
  - screen management,
  - hotspot markup,
  - transitions and hints.
  - [x] hotspot drag preview line aligned with transition curve style (visual consistency in v2 editor).
- [ ] Preview and validation gate for release publish.
- [ ] Media library for reusable assets.

### 4. Fast Content Refresh (MVP variant)
- [ ] ZIP screenshot import workflow.
- [ ] Mapping screens to simulation steps.
- [ ] Validation and preview before publish.
- [ ] Content versioning support.

### 5. Mobile Learning App (Android first on CMP)
- [~] Auth screens and sessions.
- [ ] Lesson playback flow: video -> simulation -> summary.
- [ ] Smart hints on mistakes and inactivity.
- [ ] Favorites.
- [ ] Accessibility baseline:
  - large font mode,
  - high contrast mode.

### 6. Security and Reliability
- [ ] HTTPS-only config.
- [ ] Daily PostgreSQL backup job.
- [ ] Rate limiting on auth endpoints.
- [ ] Protected storage for sensitive fields.

### 7. Operations (Web Admin MVP completion)
- [ ] Group management UI/API.
- [ ] Assignment flow (group + user targets).
- [ ] Progress operational view (completed lessons based).
- [ ] Global search across courses/users/groups/lessons.
- [ ] E2E smoke coverage for auth -> authoring -> publish -> assignment.

### 8. Multiplatform Migration (Mobile)
- [x] Phase 1: Foundation (Build system, Core modules).
- [x] Phase 2: Networking (Result -> Ktor).
- [x] Phase 3: UI Foundation (Compose Multiplatform).
- [x] Phase 4: Feature Implementation.
- [x] Phase 5: iOS & Desktop targets. ✅ **COMPLETE**
  - Desktop (JVM) app fully functional
  - iOS framework ready (requires Xcode)
  - See `.context/planning/kmp_migration_complete.md` for details

## Phase 2
- [ ] Analytics module (funnel, drop-off, popularity).
- [ ] APK automated screen extraction pipeline.
- [ ] Cybersecurity trainer scenarios.
- [ ] Voice search and TTS.
- [ ] SOS notifications:
  - Telegram,
  - push to curator app.
- [ ] Offline mode:
  - content cache,
  - deferred sync,
  - progress conflict rule `last_write_wins`.
- [ ] AI features:
  - auto-summary generation with manual correction,
  - future recommendations/intelligent assistance.

## Ongoing
- [ ] Keep `.context/architecture/architecture.md` synchronized with implementation.
- [ ] Keep `.context/operations/dependency_policy.md` updated with library/version decisions.
- [ ] Keep `.context/planning/current_focus.md` aligned with active sprint.
- [ ] Add new dedicated `.context/*.md` when domain logic becomes non-trivial.
- [ ] Track tech debt and refactoring queue per module.

## Execution Reference
- Main sprint plan and implementation backlog:
  - `.context/planning/web_admin_mvp_backlog.md`
