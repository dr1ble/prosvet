# Web Admin MVP Backlog (Authoring-First)

## 1. Objective
Deliver production-ready web-admin MVP focused on full course authoring and release operations:
- auth -> dashboard -> authoring -> moderation -> publish,
- no-code simulation builder,
- groups/assignments/progress overview,
- flexible DB-driven RBAC,
- global search.

Analytics dashboards are explicitly out of MVP and moved to Phase 2.

## 2. Planning Assumptions
- Sprint cadence: 1 week.
- Team shape (baseline):
  - 1 backend engineer,
  - 1 frontend engineer,
  - 1 QA/owner acceptance.
- Delivery style: vertical slices with working UI + API + DB migration per sprint.

## 3. MVP Epics
- `E1` Auth + Admin Shell
- `E2` Flexible RBAC Policy Engine
- `E3` Authoring CRUD (`course -> module -> lesson`)
- `E4` No-Code Simulation Builder (`screen -> hotspot -> transition -> hints`)
- `E5` Release Workflow (`draft -> review -> approved -> published`)
- `E6` Groups, Assignments, Progress (operational)
- `E7` Global Search
- `E8` Hardening (tests, performance, audit)

## 4. Sprint Plan

### Sprint 1: Auth and Dashboard Shell (E1)
Goal:
- stable entry flow and permission-aware navigation shell.

Backend:
- finalize login/refresh/logout auth behavior and error contracts,
- add `GET /api/v1/auth/me` with role and permission payload,
- ensure session refresh/logout behavior for web-admin cookies.

Frontend:
- auth page with login/password flow,
- dashboard tiles rendered from permission payload,
- top shell (global search placeholder, language switch, breadcrumbs).

DB/Infra:
- ensure `users`, `sessions`, `qr_login_tokens` indexes are in place,
- audit auth events in DB.

Acceptance:
- user can sign in and land on dashboard,
- unauthorized routes redirect to auth,
- hidden actions are not rendered when permission is missing.

### Sprint 2: DB-Driven RBAC Policy (E2)
Goal:
- remove hardcoded role-action logic.

Backend:
- tables: `roles`, `permissions`, `role_permissions`, `user_roles`,
- policy evaluator with `deny > allow`, scopes `global|group|own`,
- `/api/v1/admin/policies/*` endpoints for admin policy management,
- `/api/v1/auth/me` returns computed permission set.

Frontend:
- admin-only policy editor:
  - resource/action toggles,
  - role preview,
  - save/publish policy changes.

Audit:
- log policy updates (`actor`, `before`, `after`, timestamp).

Acceptance:
- policy changed in UI immediately affects action visibility/enforcement,
- only admin can modify policy,
- one user has one active role.

### Sprint 3: Course Structure Constructor (E3)
Goal:
- complete CRUD for course/module/lesson with drag-and-drop ordering.

Backend:
- endpoints for create/read/update/archive/restore:
  - `courses`, `modules`, `lessons`,
- ordering endpoints with transactional reindex,
- course isolation guard (no cross-course sharing).

Frontend:
- tree layout:
  - left course structure panel,
  - add/edit/archive flows,
  - drag-and-drop reorder for modules/lessons,
- form validation and inline errors.

Acceptance:
- full lifecycle for course/module/lesson works from UI,
- reorder persists after page reload,
- archive hides entities from default lists.

### Sprint 4: Screen Editor Baseline (E4)
Goal:
- enable screen-level authoring with required lesson types.

Backend:
- `screens` entity CRUD with type support:
  - `video`, `simulation`, `quiz`, `summary`,
- validation for required fields,
- media linkage and asset references.

Frontend:
- screen list editor inside lesson,
- create/edit/archive/reorder screens,
- type-specific forms:
  - quiz supports required `time_limit`, optional `passing_score`, `attempt_limit`, `shuffle_questions`.

Acceptance:
- lesson can be fully composed from screen blocks,
- schema validation blocks invalid saves.

### Sprint 5: No-Code Simulation Builder (E4)
Goal:
- visual simulation constructor usable by methodologist.

Backend:
- hotspot/transition/hint endpoints,
- graph consistency validators (reachable nodes, dead-end checks).

Frontend:
- canvas with screenshot overlay,
- hotspot draw/edit/remove,
- transition graph editor,
- hint editor (nudge/explicit/show-zone),
- draft save + preview runner.

Acceptance:
- editor supports full scenario authoring without JSON editing,
- preview reproduces learner path,
- validation catches broken flows.

### Sprint 6: Release and Moderation Workflow (E5)
Goal:
- deliver publish pipeline with version compatibility range.

Backend:
- release state transitions:
  - `draft -> review -> approved -> published`,
- `app_version_range` validation,
- moderation comments and reject reasons,
- publish gating with validation blockers.

Frontend:
- release panel with status actions,
- moderation queue for moderator/admin,
- published release edit flow (allowed by business policy).

Acceptance:
- each transition has role-checked endpoint,
- invalid release cannot be published,
- mobile latest-release endpoint reflects published data correctly.

### Sprint 7: Groups, Assignments, Progress, Search (E6 + E7)
Goal:
- complete operational loop after content publication.

Backend:
- groups CRUD,
- user-group membership,
- course assignment to group and individual user,
- progress query endpoints (completed lessons model),
- global search endpoint across courses/lessons/users/groups.

Frontend:
- groups screen,
- assignment UI,
- progress screen (operational view, not advanced analytics),
- global search in top shell with grouped results.

Acceptance:
- curator/moderator/admin can manage groups and assignments by policy,
- search respects permission scope,
- progress filters by group/user/course.

### Sprint 8: Hardening and Release Candidate (E8)
Goal:
- reliability, performance, test coverage, and release readiness.

Backend:
- integration tests for RBAC enforcement and release transitions,
- regression tests for policy evaluator and simulation validators,
- query/index optimization for search and progress.

Frontend:
- e2e smoke flows:
  - auth,
  - authoring,
  - publish,
  - assignment,
- UX polish and accessibility pass,
- error handling normalization.

Acceptance:
- CI green on lint/type-check/tests,
- no P0/P1 known defects,
- MVP demo scenario passes end-to-end.

## 5. Cross-Sprint Definition of Done
Each delivered backlog item must include:
1. API contract updated (schemas/examples).
2. DB migration and rollback notes.
3. UI behavior documented in `.context` if logic is non-trivial.
4. Permission checks both in backend and UI rendering.
5. Tests:
   - backend unit/integration,
   - frontend critical path checks.
6. Audit events for critical actions.

## 6. MVP Out-of-Scope (Locked)
- analytics dashboards,
- policy version rollback UI,
- user-level permission overrides,
- hard-delete workflows,
- notifications center.

## 7. Immediate Execution Queue
1. Sprint 1 task breakdown and estimation.
2. Sprint 2 DB schema design for RBAC tables.
3. Sprint 3 UI information architecture for course tree.
