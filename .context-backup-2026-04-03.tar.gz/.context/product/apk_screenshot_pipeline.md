# Автоматический захват скриншотов сторонних APK

Техническое исследование: как по загруженному APK автоматически получить скриншоты всех экранов и интегрировать их в библиотеку симуляций платформы DigitalEdu.

---

## Постановка задачи

**Входные данные:** APK-файл стороннего Android-приложения  
**Ожидаемый результат:** набор скриншотов всех уникальных экранов приложения, загруженных в `SimulationMediaAsset` и привязанных к `app_package_name`

```mermaid
flowchart LR
    APK["📦 APK-файл"] --> Pipeline["⚙️ Pipeline обработки"]
    Pipeline --> Emulator["📱 Android-эмулятор"]
    Emulator --> Crawler["🤖 UI-краулер"]
    Crawler --> Screenshots["📸 Скриншоты"]
    Screenshots --> API["☁️ Backend API"]
    API --> Library["📚 Библиотека медиа"]
```

---

## Обзор инструментов

### 1. Firebase Test Lab — Robo Test

| Параметр | Значение |
|----------|---------|
| **Тип** | Облачный сервис Google |
| **Ограничения** | 5 бесплатных тестов/день (Spark), требует Google Cloud проект |
| **Качество обхода** | ~70-80% экранов, ML-основанный |
| **Авторизация** | Поддержка Robo Script для логин-экранов |
| **Время** | 2-10 мин на APK |

```bash
# Запуск
gcloud firebase test android run \
  --type robo \
  --app ./target.apk \
  --timeout 300s \
  --results-bucket gs://my-bucket \
  --results-dir run-$(date +%s)

# Скачивание скриншотов
gsutil cp -r gs://my-bucket/run-*/artifacts/ ./screenshots/
```

> [!WARNING]
> Ограничение — 5 запусков/день на бесплатном тарифе. Для неограниченного использования нужен Blaze plan (оплата за минуту эмулятора ~$1/час).

---

### 2. DroidBot (open-source, рекомендуется для self-hosted)

| Параметр | Значение |
|----------|---------|
| **Тип** | Open-source Python-инструмент |
| **Ограничения** | ❌ Нет — self-hosted, полностью бесплатный |
| **Качество обхода** | ~60-70%, стратегии: DFS/BFS/random |
| **Авторизация** | Ограниченная (нет встроенного механизма для логина) |
| **Время** | 3-15 мин на APK |

```bash
pip install droidbot

droidbot -a target.apk \
  -o output_dir \
  -is_emulator \
  -timeout 300 \
  -policy dfs_greedy \
  -count 200 \
  -keep_env \
  -grant_perm
```

**Выходная структура:**
```
output_dir/
├── states/               # Скриншоты каждого уникального UI-стейта
│   ├── screen_0.png
│   ├── screen_1.png
│   └── ...
├── utg.js                # UI Transition Graph (граф переходов)
├── utg.dot               # Граф в формате Graphviz
└── log.txt
```

> [!TIP]
> DroidBot автоматически **дедуплицирует** экраны — если один и тот же экран встречается повторно, он не создаёт дубликат скриншота.

---

### 3. Android Emulator + UI Automator (полный контроль)

Собственный краулер через Android UIAutomator:

```python
import subprocess, xml.etree.ElementTree as ET, hashlib, time

def get_hierarchy():
    """Получить XML-дерево UI элементов текущего экрана"""
    subprocess.run(["adb", "shell", "uiautomator", "dump", "/sdcard/ui.xml"])
    subprocess.run(["adb", "pull", "/sdcard/ui.xml", "/tmp/ui.xml"])
    return ET.parse("/tmp/ui.xml")

def screenshot(name: str):
    """Сделать скриншот текущего экрана"""
    subprocess.run(["adb", "shell", "screencap", "-p", f"/sdcard/{name}.png"])
    subprocess.run(["adb", "pull", f"/sdcard/{name}.png", f"./screenshots/{name}.png"])

def get_screen_hash(tree) -> str:
    """Хэш экрана для дедупликации"""
    content = ET.tostring(tree.getroot(), encoding="unicode")
    return hashlib.md5(content.encode()).hexdigest()

def find_clickables(tree):
    """Найти все кликабельные элементы на экране"""
    root = tree.getroot()
    clickables = []
    for node in root.iter("node"):
        if node.get("clickable") == "true":
            bounds = node.get("bounds")  # [x1,y1][x2,y2]
            # парсим координаты, вычисляем центр
            clickables.append({
                "text": node.get("text", ""),
                "resource_id": node.get("resource-id", ""),
                "bounds": bounds,
            })
    return clickables

def crawl_app(package_name: str, max_screens=50, timeout=300):
    """Основной цикл обхода приложения"""
    visited = set()
    queue = []
    start = time.time()
    screen_count = 0
    
    while screen_count < max_screens and (time.time() - start) < timeout:
        tree = get_hierarchy()
        screen_hash = get_screen_hash(tree)
        
        if screen_hash in visited:
            subprocess.run(["adb", "shell", "input", "keyevent", "KEYCODE_BACK"])
            time.sleep(1)
            continue
        
        visited.add(screen_hash)
        screenshot(f"screen_{screen_count}")
        screen_count += 1
        
        clickables = find_clickables(tree)
        for elem in clickables:
            # клик по элементу → рекурсивно исследуем
            # ...
```

> [!IMPORTANT]
> Этот подход даёт максимум контроля, но требует значительной доработки: обработка диалогов, пермишенов, back-navigation, зацикливания.

---

### 4. Appium + python-crawler

```python
from appium import webdriver
from appium.options.android import UiAutomator2Options

options = UiAutomator2Options()
options.app = "/path/to/target.apk"
options.auto_grant_permissions = True

driver = webdriver.Remote("http://localhost:4723", options=options)

# Обход экранов
visited_screens = set()

def explore():
    page_source = driver.page_source
    screen_hash = hash(page_source)
    
    if screen_hash in visited_screens:
        driver.back()
        return
    
    visited_screens.add(screen_hash)
    driver.save_screenshot(f"./screenshots/screen_{len(visited_screens)}.png")
    
    clickable = driver.find_elements(by="xpath", value="//*[@clickable='true']")
    for elem in clickable:
        try:
            elem.click()
            time.sleep(2)
            explore()  # рекурсия
        except:
            pass

explore()
driver.quit()
```

---

### 5. 🧠 AutoDroid — LLM-управляемый краулер (интеллектуальный обход)

> [GitHub: MobileLLM/AutoDroid](https://github.com/MobileLLM/AutoDroid) · [Статья: arXiv:2308.15272](https://arxiv.org/abs/2308.15272)

AutoDroid — исследовательский фреймворк, который использует **GPT (LLM)** для интеллектуальной навигации по Android-приложениям. Построен поверх DroidBot, но вместо механического DFS/BFS обхода использует языковую модель для принятия решений.

| Параметр | Значение |
|----------|---------|
| **Тип** | Open-source, LLM-powered, построен на DroidBot |
| **Ограничения** | Требуется OpenAI API key (платный) |
| **Качество обхода** | ✅ **~80-90%** — LLM понимает контекст UI |
| **Авторизация** | ✅ GPT сам может заполнять формы логина |
| **Время** | 5-20 мин (зависит от задержек GPT API) |
| **Лицензия** | MIT |

#### Как это работает

```mermaid
flowchart LR
    subgraph AutoDroid["AutoDroid (цикл)"]
        Screenshot["📸 Screenshot + View Hierarchy"]
        Prompt["📝 make_prompt()"]
        GPT["🧠 GPT-3.5/4"]
        Action["👆 extract_action()"]
        ADB["📱 ADB touch/input"]
    end

    Screenshot --> Prompt
    Prompt --> GPT
    GPT --> Action
    Action --> ADB
    ADB --> Screenshot
```

1. **Захват состояния** — скриншот + XML view hierarchy текущего экрана
2. **Формирование промпта** (`make_prompt()`) — описание UI-элементов в HTML-подобном формате с id, задача и история действий
3. **GPT принимает решение** — какой элемент нажать / что ввести / задача завершена?
4. **Выполнение действия** через ADB — tap, input text, back
5. **Повтор** — пока GPT не скажет "задача завершена" или не истечёт таймаут

#### Пример промпта (из `tools.py`)

```
You are a smartphone assistant to help users complete tasks 
by interacting with mobile apps.

Task: explore all screens of the app and capture screenshots
Previous UI actions: [tap on "Settings", tap on "Profile"]
Current UI state:
<button id=0 class='Back'></button>
<p id=1>User Profile</p>
<input id=2 class='Name'>John Doe</input>
<button id=3 class='Save'></button>
<button id=4 class='Logout'></button>

Your answer:
1. Steps: <?>
2. Analysis: <?>  
3. Is task finished? <Y/N>
4. Next interaction: id=<id> action=<tap/input> input text=<text or N/A>
```

#### Ключевые файлы

| Файл | Назначение |
|------|-----------|
| `tools.py` | `make_prompt()`, `query_gpt()`, `extract_action()` — ядро LLM-интеграции |
| `droidbot/input_policy.py` | `TaskPolicy` — политика принятия решений через LLM |
| `droidbot/device_state.py` | Парсинг view hierarchy, формирование HTML-описания UI |
| `droidbot/utg.py` | UI Transition Graph — граф переходов между экранами |

#### Установка и запуск

```bash
git clone https://github.com/MobileLLM/AutoDroid.git
cd AutoDroid
pip install -e .

# Зависимости: androguard, networkx, Pillow, torch, 
# InstructorEmbedding, sentence_transformers, pytesseract, openai

# Запуск с задачей "исследовать все экраны"
export APIKey="sk-..."
droidbot -a target.apk \
  -o output_dir \
  -task "explore all screens of the app and take screenshots of each screen" \
  -keep_env \
  -keep_app
```

#### Адаптация под задачу захвата скриншотов

AutoDroid изначально создан для выполнения конкретных задач ("создать контакт", "удалить событие"). Для задачи **максимального покрытия экранов** нужно:

1. **Модифицировать задачу** — вместо конкретной цели дать задачу "explore all screens"
2. **Адаптировать политику остановки** — не останавливаться при "task complete", а продолжать обход
3. **Собирать скриншоты из `states/`** — DroidBot (база AutoDroid) уже сохраняет скриншоты каждого уникального состояния

```python
# Модификация для максимального покрытия:
# В input_policy.py — изменить TaskPolicy, чтобы LLM 
# стремилась к максимальному обходу, а не к завершению задачи

EXPLORATION_TASK = """
Explore this app thoroughly. Visit every screen, tab, menu, 
and settings page. Do NOT stop until you have visited all 
reachable screens. For each new screen, interact with all 
available UI elements to discover sub-screens.
"""
```

> [!IMPORTANT]  
> **Главное преимущество AutoDroid** — GPT **понимает** UI. Там где DroidBot вслепую кликает по всем кнопкам, AutoDroid:
> - Пропускает деструктивные действия (удаление, выход из аккаунта)
> - Понимает, что кнопка "Войти" →  нужно сначала заполнить поля
> - Различает уже посещённые экраны по смыслу, а не только по пикселям
> - Может следовать логическому порядку навигации

> [!WARNING]  
> **Ограничения AutoDroid:**
> - ~~Требует OpenAI API key~~ → **Решаемо!** См. секцию "Бесплатные LLM" ниже
> - Зависимость от тяжёлых ML-библиотек (torch, sentence_transformers) — **Docker-образ будет ~5-8GB**
> - Нестабильность из-за рандомности LLM — один и тот же APK может дать разные результаты
> - Research-level код, не production-ready

---

### 6. 🆓 Бесплатные LLM для AutoDroid (замена OpenAI)

AutoDroid использует OpenAI API через одну функцию — `query_gpt()` в `tools.py`. Её легко заменить на **бесплатную альтернативу**, т.к. все провайдеры поддерживают OpenAI-совместимый формат.

#### Варианты бесплатных LLM

| Провайдер | Модель | Лимит | Качество | Задержка |
|-----------|--------|-------|----------|----------|
| **Ollama (локально)** | Llama 3.1 8B, Gemma 2 9B, Qwen 2.5 7B | ♾️ Безлимит | 🟡 | ⚡ ~1-3 сек |
| **Gemini Flash-Lite** | gemini-2.5-flash-lite | 1000 req/день | ✅ | ⚡ ~1-2 сек |
| **Groq** | Llama 3.3 70B, Mixtral 8x7B | 14400 req/день | ✅ | ⚡⚡ ~0.3 сек |
| **Cloudflare Workers AI** | Llama 3.3 | 10000 req/день | 🟡 | 🟡 ~2-5 сек |

#### Вариант A: Ollama (100% локально, 0 затрат, безлимит)

**Лучший вариант** — полностью бесплатный, не требует интернета, без лимитов.

```bash
# Установка Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Скачать модель (~5 GB)
ollama pull llama3.1:8b
# или более лёгкую
ollama pull gemma2:9b
# или qwen2.5:7b  (хорошо работает с UI-описаниями)
```

**Модификация `tools.py` AutoDroid:**

```python
# БЫЛО (платно):
from openai import OpenAI

def query_gpt(prompt):
    client = OpenAI(api_key=os.environ['APIKey'])
    completion = client.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model="gpt-3.5-turbo",
        timeout=15
    )
    return completion.choices[0].message.content

# СТАЛО (бесплатно, через Ollama):
from openai import OpenAI

def query_gpt(prompt):
    client = OpenAI(
        base_url="http://localhost:11434/v1",  # Ollama OpenAI-совместимый API
        api_key="ollama"                        # любая строка
    )
    completion = client.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model="llama3.1:8b",   # или gemma2:9b / qwen2.5:7b
        timeout=30
    )
    return completion.choices[0].message.content
```

> [!TIP]
> Ollama поддерживает **OpenAI-совместимый API** из коробки (`/v1/chat/completions`). Менять нужно только `base_url` и `model` — **2 строки кода**.

#### Вариант B: Google Gemini (бесплатный API, облачный)

```python
def query_gpt(prompt):
    client = OpenAI(
        base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
        api_key=os.environ['GEMINI_API_KEY']  # бесплатный ключ с ai.google.dev
    )
    completion = client.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model="gemini-2.5-flash-lite",  # 1000 req/день бесплатно
        timeout=15
    )
    return completion.choices[0].message.content
```

#### Вариант C: Groq (бесплатный, сверхбыстрый)

```python
def query_gpt(prompt):
    client = OpenAI(
        base_url="https://api.groq.com/openai/v1",
        api_key=os.environ['GROQ_API_KEY']  # бесплатный ключ с console.groq.com
    )
    completion = client.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model="llama-3.3-70b-versatile",  # 14400 req/день бесплатно
        timeout=15
    )
    return completion.choices[0].message.content
```

#### Универсальная реализация (поддержка всех провайдеров)

```python
import os
from openai import OpenAI

# Конфигурация через переменные окружения
LLM_PROVIDERS = {
    "ollama":  {"base_url": "http://localhost:11434/v1",  "model": "llama3.1:8b"},
    "gemini":  {"base_url": "https://generativelanguage.googleapis.com/v1beta/openai/", "model": "gemini-2.5-flash-lite"},
    "groq":    {"base_url": "https://api.groq.com/openai/v1",  "model": "llama-3.3-70b-versatile"},
    "openai":  {"base_url": "https://api.openai.com/v1",  "model": "gpt-3.5-turbo"},
}

def query_gpt(prompt):
    provider = os.environ.get("LLM_PROVIDER", "ollama")
    config = LLM_PROVIDERS[provider]
    
    client = OpenAI(
        base_url=config["base_url"],
        api_key=os.environ.get("LLM_API_KEY", "ollama")
    )
    completion = client.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model=os.environ.get("LLM_MODEL", config["model"]),
        timeout=30
    )
    return completion.choices[0].message.content
```

> [!IMPORTANT]
> **Вывод: AutoDroid можно использовать полностью бесплатно!**
> - **Ollama** — безлимит, работает локально, достаточно модели 7-8B для навигации по UI
> - Менять нужно **только 2 строки** в `tools.py` — `base_url` и `model`
> - Качество Llama 3.1 8B для задачи "куда нажать на экране" — **адекватное** (не GPT-4, но для UI навигации хватает)

---

## Сравнительная таблица

| Критерий | Firebase Robo | DroidBot | AutoDroid + Ollama | AutoDroid + Gemini | UIAutomator |
|----------|:---:|:---:|:---:|:---:|:---:|
| **Полностью бесплатно** | ❌ 5/день | ✅ | ✅ | ✅ (1000/день) | ✅ |
| **Self-hosted** | ❌ Облако | ✅ | ✅ | ✅ | ✅ |
| **Сложность настройки** | ⚡ Низкая | 🟡 Средняя | 🔴 Высокая | 🟡 Средняя | 🔴 Высокая |
| **Качество обхода** | ✅ ~80% | 🟡 ~60-70% | ✅ ~80-90% | ✅ ~85-90% | 🟡 Зависит |
| **Поддержка логина** | ✅ Robo Script | ❌ | ✅ LLM сам | ✅ LLM сам | ✅ Скрипт |
| **Интеллект навигации** | 🟡 ML | ❌ Механический | ✅ LLM | ✅ LLM | ❌ |
| **Дедупликация** | ✅ Авто | ✅ Авто | ✅ Авто | ✅ Авто | 🔧 Ручная |
| **Стоимость** | 💵 | 🆓 | 🆓 | 🆓 | 🆓 |
| **Docker-образ** | N/A | ~2 GB | ~8 GB | ~8 GB | ~2 GB |
| **Интернет нужен** | ✅ | ❌ | ❌ | ✅ | ❌ |

---

## Рекомендуемая архитектура: AutoDroid + Ollama + Docker (100% бесплатно)

```mermaid
flowchart TD
    subgraph web-admin["Web-Admin (Next.js)"]
        Upload["📦 Загрузка APK"]
        Gallery["🖼 Галерея скриншотов"]
    end

    subgraph worker["Screenshot Worker (Docker)"]
        Ollama["🧠 Ollama (Llama 3.1)"]
        Emulator["📱 Android Emulator"]
        AutoDroid["🤖 AutoDroid"]
        Dedup["🔍 Дедупликация"]
        Uploader["📤 Upload Script"]
    end

    subgraph backend["Backend (FastAPI)"]
        APK_API["POST /api/v1/simulation/apk-scan"]
        Media_API["POST /api/v1/simulation/media/upload"]
        DB[(PostgreSQL)]
        Storage["📂 File Storage"]
    end

    Upload --> APK_API
    APK_API --> |"Запускает задачу"| worker
    AutoDroid --> |"промпт"| Ollama
    Ollama --> |"решение"| AutoDroid
    Emulator --> AutoDroid
    AutoDroid --> |"Сырые скриншоты"| Dedup
    Dedup --> |"Уникальные экраны"| Uploader
    Uploader --> Media_API
    Media_API --> DB
    Media_API --> Storage
    Gallery --> Media_API
```

### Docker Compose (всё бесплатно)

```yaml
services:
  # Локальная LLM 
  ollama:
    image: ollama/ollama:latest
    volumes:
      - ollama_data:/root/.ollama
    deploy:
      resources:
        reservations:
          memory: 6G
    # При запуске скачает модель:
    # docker exec ollama ollama pull llama3.1:8b

  # Android Emulator + AutoDroid
  screenshot-worker:
    image: budtmo/docker-android:emulator_14.0
    privileged: true   # для KVM
    environment:
      - EMULATOR_DEVICE=pixel_6
      - LLM_PROVIDER=ollama
      - LLM_API_KEY=ollama
      - LLM_BASE_URL=http://ollama:11434/v1
      - LLM_MODEL=llama3.1:8b
      - BACKEND_URL=http://backend:8000
      - API_TOKEN=${API_TOKEN}
    depends_on:
      - ollama
    volumes:
      - ./apks:/apks
      - ./output:/output

volumes:
  ollama_data:
```

### Скрипт обработки (`scan_apk.py`)

```python
"""
Полностью бесплатный пайплайн:
APK → AutoDroid + Ollama → Скриншоты → Backend API
"""
import os, sys, subprocess
from pathlib import Path
import requests

BACKEND_URL = os.environ["BACKEND_URL"]
API_TOKEN = os.environ["API_TOKEN"]
SCOPE_KEY = os.environ.get("SCOPE_KEY", "global")

def extract_apk_info(apk_path: str) -> tuple[str, str]:
    """Извлекаем package name и версию из APK"""
    result = subprocess.run(
        ["aapt", "dump", "badging", apk_path],
        capture_output=True, text=True
    )
    package_name = "unknown"
    version = "1.0.0"
    for line in result.stdout.split("\n"):
        if line.startswith("package:"):
            package_name = line.split("name='")[1].split("'")[0]
        if "versionName=" in line:
            version = line.split("versionName='")[1].split("'")[0]
    return package_name, version

def run_autodroid(apk_path: str, output_dir: str, timeout: int = 300):
    """Запуск AutoDroid с локальной LLM"""
    subprocess.run([
        "droidbot",
        "-a", apk_path,
        "-o", output_dir,
        "-is_emulator",
        "-timeout", str(timeout),
        "-task", "Explore all screens of this app thoroughly. "
                 "Visit every tab, menu, settings page. "
                 "Do NOT stop until all screens are visited.",
        "-keep_env",
        "-grant_perm",
    ], check=True)

def upload_screenshots(output_dir: str, package_name: str, version: str):
    """Загрузка скриншотов на бэкенд"""
    states_dir = Path(output_dir) / "states"
    uploaded = 0
    for img in sorted(states_dir.glob("*.png")):
        with open(img, "rb") as f:
            resp = requests.post(
                f"{BACKEND_URL}/api/v1/simulation/media/upload",
                params={
                    "scope_key": SCOPE_KEY,
                    "app_package_name": package_name,
                    "store_type": "play_market",
                    "min_supported_version": version,
                    "max_supported_version": version,
                },
                files={"file": (img.name, f, "image/png")},
                headers={"Authorization": f"Bearer {API_TOKEN}"},
            )
            resp.raise_for_status()
            uploaded += 1
    return uploaded

def main():
    apk_path = sys.argv[1]
    output_dir = "/tmp/autodroid_output"
    
    pkg, ver = extract_apk_info(apk_path)
    print(f"📦 {pkg} v{ver}")
    print(f"🧠 LLM: {os.environ.get('LLM_MODEL', 'llama3.1:8b')} via Ollama")
    
    run_autodroid(apk_path, output_dir)
    
    count = upload_screenshots(output_dir, pkg, ver)
    print(f"✅ Загружено {count} скриншотов для {pkg}")

if __name__ == "__main__":
    main()
```

---

## Обработка особых случаев

### Экраны с авторизацией

| Инструмент | Подход |
|-----------|--------|
| Firebase Robo | Robo Script — предзаписанный JSON-скрипт |
| DroidBot | Нет встроенной поддержки |
| **AutoDroid + Ollama** | **LLM сам заполняет логин-форму** |
| UIAutomator/Appium | Скриптуемо вручную |

Для AutoDroid передаём тестовые данные в задаче:
```
droidbot -a app.apk -task "Login with email test@example.com and 
  password Test123, then explore all screens"
```

### Дедупликация скриншотов

```python
from PIL import Image
import imagehash

def deduplicate_screenshots(directory: str, threshold: int = 8):
    """Perceptual hashing — удаляем визуально похожие скриншоты"""
    hashes = {}
    duplicates = []
    for img_path in Path(directory).glob("*.png"):
        h = imagehash.phash(Image.open(img_path))
        if any(abs(h - eh) < threshold for eh in hashes):
            duplicates.append(img_path)
        else:
            hashes[h] = img_path
    for dup in duplicates:
        dup.unlink()
    return len(duplicates)
```

---

## Системные требования

| Ресурс | DroidBot | AutoDroid + Ollama | Рекомендуется |
|--------|---------|---------|---------------|
| **CPU** | 2 ядра | 4 ядра | 4+ ядра |
| **RAM** | 4 GB | 10 GB (LLM + эмулятор) | 12-16 GB |
| **Disk** | 10 GB | 25 GB (модель ~5GB) | 30 GB |
| **KVM** | Требуется | Требуется | — |
| **GPU** | Не нужен | Опционально (ускоряет LLM) | — |
| **OS** | Linux | Linux | Ubuntu 22.04+ |

> [!CAUTION]
> Android-эмулятор требует **KVM**. CI-runner должен быть на выделенном сервере с nested-виртуализацией. Варианты:
> - Self-hosted GitHub Actions runner на VPS
> - Выделенный сервер с Docker
> - **macOS runners** — поддерживают HAXM

---

## План реализации

### Фаза 1: PoC — DroidBot (1 день)
- [ ] Установить DroidBot локально
- [ ] Протестировать на 2-3 APK, оценить покрытие

### Фаза 2: PoC — AutoDroid + Ollama (1-2 дня)
- [ ] Установить Ollama + Llama 3.1 8B
- [ ] Установить AutoDroid, заменить `query_gpt()` на Ollama
- [ ] Протестировать на тех же APK, сравнить покрытие с DroidBot
- [ ] Попробовать разные модели (Gemma 2, Qwen 2.5)

### Фаза 3: Backend API (1-2 дня)
- [ ] Эндпоинт `POST /simulation/apk-scan`
- [ ] Модель `ApkScanJob` (статус, прогресс, результаты)
- [ ] Background worker

### Фаза 4: Docker + CI (1-2 дня)
- [ ] Docker Compose: Ollama + Android Emulator + AutoDroid
- [ ] `scan_apk.py` с загрузкой на бэкенд
- [ ] Интеграция с основной инфраструктурой

### Фаза 5: Web-Admin UI (1-2 дня)
- [ ] Форма загрузки APK
- [ ] Прогресс сканирования
- [ ] Галерея скриншотов

---

## Вывод

| Компонент | Технология | Стоимость |
|-----------|-----------|-----------|
| **Краулер** | AutoDroid (LLM-навигация по UI) | 🆓 |
| **LLM** | Ollama + Llama 3.1 8B (локально) | 🆓 |
| **Эмулятор** | Docker-Android (`budtmo/docker-android`) | 🆓 |
| **Очередь задач** | Celery + Redis или asyncio | 🆓 |
| **Хранение** | `SimulationMediaAsset` + file storage | 🆓 |
| **ИТОГО** | | **$0** |

> [!TIP]
> **Стратегия:** AutoDroid + Ollama = 100% бесплатный интеллектуальный обход. Единственная инвестиция — сервер с KVM и 10+ GB RAM (любой VPS ~$10-20/мес или свой компьютер).
