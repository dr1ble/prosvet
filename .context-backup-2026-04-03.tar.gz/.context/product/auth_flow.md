# Auth Flow

## Scope
- MVP authentication channels:
  - phone + SMS OTP (primary self-auth),
  - curator-issued QR token (alternative).

## Actors
- `User` (mobile app end user).
- `Curator` (issues QR through admin tools).
- `Backend Auth Service`.

## Flow A: Phone OTP
1. User enters phone number.
2. Mobile app calls `POST /api/v1/auth/otp/request`.
3. Backend creates OTP challenge and sends SMS.
4. User enters OTP code.
5. Mobile app calls `POST /api/v1/auth/otp/verify`.
6. Backend validates challenge and returns access+refresh tokens.
7. Session is tied to device fingerprint/hash.

### Constraints
- OTP lifetime: `5 minutes`.
- Max attempts: `5`.
- Temporary block after limit: `15 minutes`.
- Endpoint rate limiting is mandatory.

## Flow B: Curator QR
1. Curator generates QR token from admin panel.
2. User scans QR in mobile app.
3. Mobile app calls `POST /api/v1/auth/qr/activate`.
4. Backend validates token and creates session.
5. Backend invalidates token after first successful use.

### Constraints
- QR token lifetime: `24 hours`.
- Token is one-time and invalidated on first success.

## Session Model
- Access token: short TTL (example: 15 minutes).
- Refresh token: longer TTL (example: 7-30 days, configurable).
- Refresh rotation on each refresh operation.
- Store refresh token hash only.

## Error Scenarios
- Expired OTP -> return explicit code, allow resend.
- Blocked challenge -> return retry-after info.
- Expired/used QR -> return invalid token response.
- Too many requests -> HTTP `429` + retry window.

## Audit and Security
- Log auth events:
  - otp requested/verified/failed,
  - qr generated/used/expired,
  - session refreshed/revoked.
- Do not store plain OTP or plain token values in DB.
- Store phone protected at rest (hash/encryption policy).

## Phase 2 Extensions
- Optional additional channels (email/passwordless, social, etc.) if needed.
- Step-up auth and risk scoring can be added in separate module.
