# Content Refresh Pipeline

## Goal
- Provide fast updates of simulation screens when source app UI changes.
- Keep methodologist workflow simple and auditable.

## MVP Strategy (Hybrid: ZIP Import)

### Input
- Methodologist uploads ZIP archive with screenshots.
- Naming convention example:
  - `screen_001_home.png`
  - `screen_002_profile.png`
  - `screen_003_payment.png`

### Pipeline Steps
1. Create import batch (`screen_import_batches`).
2. Unpack archive and validate:
  - file type (`png`, `jpg`),
  - size limits,
  - duplicate keys.
3. Upload valid images to media storage (`media_assets`).
4. Create import items (`screen_import_items`) with mapping state.
5. Methodologist maps `screen_key` -> simulation step/screen.
6. Preview updated flow in web simulator.
7. Apply import to draft lesson version.
8. Send lesson version to moderation.

## Implemented Baseline (Current Backend)
- Added persistent course release storage optimized for fast mobile updates:
  - `courses`
  - `course_releases`
  - `course_release_screens` (`payload_json` + checksum)
- Added API endpoints:
  - `POST /api/v1/catalog/courses`
  - `POST /api/v1/catalog/courses/{course_id}/releases`
  - `GET /api/v1/catalog/courses/{course_slug}/releases/latest`
- Mobile sync contract now can download the latest published screen bundle without app rebuild.

### Validation Rules
- No missing required screens for selected scenario.
- All hotspots must target existing screens.
- Transition graph must have start screen and at least one terminal path.
- Broken mappings block publication.

## Versioning Rules
- Imports are applied only to draft lesson versions.
- Published versions remain immutable.
- New import creates next draft version (or updates active draft only).
- Every apply operation is recorded in audit logs.

## Phase 2 Strategy (APK Automation)

### Planned Extension
- Add `apk_extractor` worker module:
  - receives APK,
  - runs scripted navigation in emulator/device farm,
  - captures screens,
  - creates suggested mappings.

### Safety
- APK processing must be isolated worker execution.
- Captures require validation review before publish.
- Automated extraction never bypasses moderator approval flow.

## Open Technical Notes for Phase 2
- Navigation script format (YAML/JSON DSL).
- Device matrix and resolution normalization.
- Handling dynamic/personalized content masking in captured screens.
