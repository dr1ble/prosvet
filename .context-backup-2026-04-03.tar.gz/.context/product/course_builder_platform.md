# Course Builder Platform (MVP)

## Goal
Build a no-code authoring platform to quickly train older adults in digital literacy through guided simulations:
- screenshots + clickable zones,
- step-by-step hints,
- safe error recovery,
- clear progress tracking by completed lessons.

## Product Core
- Audience: older adults with low digital confidence.
- Primary value: fast content updates and fast course publication.
- Authoring model: `Course -> Module -> Lesson -> Screen`.
- Delivery model: published release bundle consumed by mobile app.

## Learning Design for 60+
Use one stable template per lesson:
1. Intro: what user will learn.
2. Demo: short visual explanation.
3. Guided simulation: user acts with hints.
4. Independent simulation: same flow with fewer hints.
5. Summary + mini-check.

Rules:
- one action per step,
- large touch targets,
- plain language,
- progressive hints from soft to explicit.

## No-Code Authoring UX
Stepik-like structure + simulation builder.

### Workspace Layout
1. Left panel:
- course tree (modules, lessons, screens),
- drag-and-drop ordering.
2. Center panel:
- screen canvas (screenshot),
- hotspot overlay editor.
3. Right panel:
- selected item properties (screen/hotspot/hint/transition).
4. Bottom panel:
- flow graph (screen nodes + transitions).

### Authoring Modes
1. Structure mode:
- create/edit course/module/lesson metadata.
2. Simulation mode:
- place hotspots,
- define actions and transitions,
- configure hints.
3. Preview mode:
- run learner scenario from any screen,
- validate touch zones and hint timing.

## Simulation Domain Model
For each lesson:
- `screens[]`
  - `id`, `title`, `type` (`video|simulation|quiz|summary`), `asset_key`, `order`.
- `hotspots[]`
  - `screen_id`, geometry (`x,y,w,h`), `action_type`, `payload`.
- `transitions[]`
  - `from_hotspot_id`, `to_screen_id`, `condition`, `is_success`.
- `hints[]`
  - `scope` (`screen|hotspot`), `level` (`nudge|explicit|show-zone`), `trigger`.

Release:
- `status`: `draft -> review -> approved -> published`.
- `app_version_range`: semver range for compatibility.
- soft-delete only.

## Permissions (Action-Level)
Role model:
- `admin`: full access.
- `methodologist`: create/edit course content.
- `moderator`: approve/reject/quality control.
- `curator`: group assignment, learner tracking.

Action-level policy required:
- explicit permission matrix for:
  - create/edit/archive course/module/lesson/screen,
  - submit for review,
  - approve/reject/publish,
  - edit published release (currently allowed by business decision).

## MVP Tooling Recommendation
Web Admin stack:
- Next.js + React + TypeScript.
- UI primitives: accessible component library + custom design system.
- Tree and drag-drop: `dnd-kit`.
- Flow graph editor: `reactflow`.
- Canvas overlays/hotspots: `react-konva` (or Fabric-based alternative).
- Forms/validation: `react-hook-form` + `zod`.
- Global state: `zustand`.

Backend:
- FastAPI + PostgreSQL.
- Separate modules: `catalog`, `authoring`, `simulation`, `moderation`, `rbac`.
- Versioned release APIs and strict audit logging in DB.

## MVP Scope Priority
Authoring-first delivery:
1. Full course constructor (course/module/lesson/screen CRUD).
2. Simulation editor (hotspots, transitions, hints).
3. Preview and validation rules.
4. Moderation and publish flow.
5. Group assignment and basic progress view.

Analytics dashboards:
- phase after authoring completeness.

## Quality Gates for Authoring
Before publish, block release if:
- no entry screen,
- dead-end flow exists,
- unreachable screens exist,
- hotspot too small,
- missing success path,
- missing required lesson metadata.
