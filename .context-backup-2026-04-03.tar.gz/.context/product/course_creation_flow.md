# Course Creation Flow (Wizard)

## Goal
Minimal UI, full functionality: create a complete course from scratch in 5 steps with auto-save and resume capability.

## Core Principles
- **One action per screen** — single primary button ("Далее" / "Сохранить")
- **Auto-save on every step** — no data loss, can exit/resume anytime
- **Draft-first** — everything saves as draft, publish is explicit final step
- **Progressive disclosure** — show only what's needed for current step

## Data Model
```
Course
└── Lesson (order, title)
    └── Module (order, type, content)
        ├── Video: { video_url, duration }
        ├── Theory: { text_content, media_attachments }
        ├── Simulation: { screens[], hotspots[], transitions[] }
        ├── Quiz: { questions[], passing_score }
        └── CheatSheet: { content, downloadable }
```

## Wizard Steps

### Step 1: Course Info
**Purpose:** Create course container

**Fields:**
- Название курса (required)
- Описание (optional)

**Actions:**
- `Сохранить черновик` — save and stay
- `Далее: Уроки` — save and proceed to Step 2

**State after:** Course created with `status=draft`

---

### Step 2: Lessons Structure
**Purpose:** Define lesson sequence

**UI:**
- List of lessons (initially empty)
- `+ Добавить урок` button
- Each lesson row: title input, drag handle, delete icon
- Reorder via drag-and-drop

**Actions:**
- `← Назад` — return to Step 1
- `Сохранить черновик` — save and stay
- `Далее: Модули` — save and proceed to Step 3

**Validation:** At least 1 lesson required to proceed

---

### Step 3: Modules Per Lesson
**Purpose:** Define module sequence for each lesson

**UI:**
- Lesson selector (tabs or dropdown)
- For selected lesson:
  - List of modules (initially empty)
  - `+ Добавить модуль` button
  - Module type selector: Video / Теория / Симуляция / Тест / Шпаргалка
  - Each module row: title, type badge, drag handle, delete icon
  - Reorder via drag-and-drop

**Actions:**
- `← Назад` — return to Step 2
- `Сохранить черновик` — save and stay
- `Далее: Содержимое` — save and proceed to Step 4

**Validation:** At least 1 module per lesson required to proceed

---

### Step 4: Content Editor
**Purpose:** Fill module content

**UI:**
- Lesson selector → Module selector (or tree view)
- Content editor based on module type:
  - **Video:** URL input, duration auto-fetch or manual
  - **Теория:** Rich text editor, file upload for attachments
  - **Симуляция:** Link to simulation builder (separate flow)
  - **Тест:** Question builder (question text, options, correct answer, explanation)
  - **Шпаргалка:** Text editor, file upload for PDF/downloadable

**Actions:**
- `← Назад` — return to Step 3
- `Сохранить черновик` — save and stay
- `Далее: Публикация` — save and proceed to Step 5

**Auto-save:** Every field change saved after 1s debounce

---

### Step 5: Preview & Publish
**Purpose:** Review and publish course

**UI:**
- Read-only preview of entire course structure
- Expandable lessons and modules
- Validation summary (errors/warnings)
- Publish checklist:
  - ✓ All lessons have modules
  - ✓ All modules have content
  - ✓ No validation errors

**Actions:**
- `← Назад` — return to Step 4
- `Сохранить черновик` — save and exit
- `Опубликовать` — publish course (makes available to learners)

**Validation before publish:**
- Course has title
- At least 1 lesson
- Each lesson has at least 1 module
- Each module has required content
- No dead-end simulation flows (if simulation modules exist)

---

## Navigation Rules

| From Step | Can Navigate To |
|-----------|-----------------|
| 1 | 2 (forward), Stay (save) |
| 2 | 1 (back), 3 (forward), Stay (save) |
| 3 | 2 (back), 4 (forward), Stay (save) |
| 4 | 3 (back), 5 (forward), Stay (save) |
| 5 | 4 (back), Exit (save), Publish |

**Resume behavior:**
- User can exit at any step
- On return, open last edited step
- All saved data preserved
- Show completion status per step (✓ indicator)

---

## UI Components Needed

### Shared
- Wizard stepper (5 steps with progress indicators)
- Auto-save indicator ("Сохранено 2 мин назад")
- Draft badge on course title

### Step-Specific
1. Text inputs (title, description)
2. Drag-drop list (lessons)
3. Nested drag-drop list (modules per lesson)
4. Rich text editor, file uploader, question builder
5. Preview panel, validation summary

---

## Backend Requirements

### Endpoints
```
POST   /api/v1/courses/                          # Step 1: Create course
PUT    /api/v1/courses/{id}/                     # Update course metadata
GET    /api/v1/courses/{id}/                     # Get course with structure
POST   /api/v1/courses/{id}/lessons/             # Step 2: Add lesson
PUT    /api/v1/courses/lessons/{id}/             # Update lesson (title, order)
DELETE /api/v1/courses/lessons/{id}/             # Delete lesson
POST   /api/v1/courses/lessons/{id}/modules/     # Step 3: Add module
PUT    /api/v1/courses/modules/{id}/             # Update module (type, order)
DELETE /api/v1/courses/modules/{id}/             # Delete module
PUT    /api/v1/courses/modules/{id}/content      # Step 4: Save module content
POST   /api/v1/courses/{id}/publish              # Step 5: Publish course
GET    /api/v1/courses/{id}/preview              # Get preview data
GET    /api/v1/courses/{id}/validation           # Get validation errors
```

### Database Models
- `Course`: id, title, description, status (draft/published/archived), created_at, updated_at
- `Lesson`: id, course_id, title, order, created_at, updated_at
- `Module`: id, lesson_id, type, title, order, content (JSONB), created_at, updated_at

### Status Transitions
```
draft --publish--> published
draft --delete--> archived
published --update--> draft (create new draft version)
published --archive--> archived
```

---

## Module Content Schemas

### 1. Video Module

**Purpose:** Show video content with optional subtitles.

**Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `video_url` | string (URL) | yes | Video file URL (MP4, WebM) |
| `duration_seconds` | integer | auto | Video duration (auto-fetched or manual) |
| `title` | string | no | Display title (optional) |
| `description` | string | no | Short description below video |

**Minimal Form:**
```
[URL видео*          ] [Загрузить]
[Название (опц)      ]
[Описание (опц)      ]
```

**JSON Schema:**
```json
{
  "type": "video",
  "content": {
    "video_url": "https://cdn.example.com/video.mp4",
    "duration_seconds": 120,
    "title": "Введение в курс",
    "description": "Краткий обзор темы"
  }
}
```

**Validation:**
- `video_url`: valid URL, accessible, video format
- `duration_seconds`: positive integer, max 3600 (1 hour)

---

### 2. Theory Module

**Purpose:** Text content with optional media.

**Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `text_content` | string (HTML/Markdown) | yes | Main text |
| `media` | array | no | Attached images/files |

**Minimal Form:**
```
[Редактор текста (textarea + formatting)         ]
[                                                 ]
[Прикрепить файл: [Выбрать]                      ]
```

**JSON Schema:**
```json
{
  "type": "theory",
  "content": {
    "text_content": "<p>Текст теории...</p>",
    "media": [
      {
        "type": "image",
        "url": "https://cdn.example.com/image.png",
        "alt": "Диаграмма"
      }
    ]
  }
}
```

**Validation:**
- `text_content`: required, min 10 chars, max 50000 chars
- `media`: optional, max 10 files, max 10MB each

---

### 3. Simulation Module

**Purpose:** Interactive step-by-step simulation.

**Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `simulation_id` | string (UUID) | yes | Link to simulation record |
| `screens` | array | yes | Ordered screen nodes |
| `hotspots` | array | yes | Clickable zones per screen |
| `transitions` | array | yes | Screen-to-screen navigation |

**Minimal Form:**
```
Симуляция: [Выбрать существующую] или [Создать новую]

Если создать новую → открывается Simulation Builder (отдельный flow)

[Превью симуляции: Структура → Экраны → Действия]
```

**JSON Schema:**
```json
{
  "type": "simulation",
  "content": {
    "simulation_id": "uuid-here",
    "entry_screen_id": "screen-1",
    "screens": [
      {
        "id": "screen-1",
        "title": "Экран 1",
        "image_url": "https://cdn.example.com/screen1.png",
        "order": 1
      }
    ],
    "hotspots": [
      {
        "id": "hotspot-1",
        "screen_id": "screen-1",
        "geometry": { "x": 100, "y": 200, "w": 50, "h": 30 },
        "action_type": "click",
        "hint_text": "Нажмите сюда"
      }
    ],
    "transitions": [
      {
        "from_hotspot_id": "hotspot-1",
        "to_screen_id": "screen-2",
        "is_success": true
      }
    ]
  }
}
```

**Validation:**
- At least 1 screen
- At least 1 hotspot per screen
- All hotspots have valid transitions
- No dead-end screens (all screens reachable)
- One entry screen defined

---

### 4. Quiz Module

**Purpose:** Knowledge check with questions.

**Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `questions` | array | yes | List of questions |
| `passing_score` | integer | yes | % needed to pass (0-100) |
| `max_attempts` | integer | no | Max retry attempts (default: 3) |

**Question Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `text` | string | yes | Question text |
| `options` | array | yes | Answer options (min 2) |
| `correct_index` | integer | yes | Index of correct answer (0-based) |
| `explanation` | string | no | Explanation shown after answer |

**Minimal Form:**
```
Вопрос 1:
[Текст вопроса*                          ]
[Вариант 1*  ] [Вариант 2*  ] [+ Добавить вариант]
Правильный ответ: [Выберите вариант ▼]
[Объяснение (опц)                       ]

[Проходной балл (%)*: 70]
[Макс попыток: 3]

[+ Добавить вопрос]
```

**JSON Schema:**
```json
{
  "type": "quiz",
  "content": {
    "passing_score": 70,
    "max_attempts": 3,
    "questions": [
      {
        "text": "Какой символ используется для...",
        "options": ["Вариант A", "Вариант B", "Вариант C"],
        "correct_index": 0,
        "explanation": "Правильный ответ: A, потому что..."
      }
    ]
  }
}
```

**Validation:**
- At least 1 question
- Each question: 2-6 options
- `correct_index` within options range
- `passing_score`: 1-100
- `max_attempts`: 1-10

---

### 5. CheatSheet Module

**Purpose:** Quick reference/summary for download.

**Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `content` | string (HTML/Markdown) | yes | Text content |
| `downloadable_url` | string (URL) | no | PDF/file for download |
| `downloadable_name` | string | no | Filename for download |

**Minimal Form:**
```
[Текст шпаргалки*                       ]
[                                        ]
[Файл для скачивания: [Выбрать]          ]
Имя файла: [shpargalka.pdf]
```

**JSON Schema:**
```json
{
  "type": "cheatsheet",
  "content": {
    "content": "<h3>Краткая справка</h3><ul><li>Пункт 1</li></ul>",
    "downloadable_url": "https://cdn.example.com/cheatsheet.pdf",
    "downloadable_name": "shpargalka.pdf"
  }
}
```

**Validation:**
- `content`: required, min 10 chars, max 20000 chars
- `downloadable_url`: optional, valid URL, max 10MB file

---

## Module Field Summary

| Type | Required Fields | Optional Fields |
|------|-----------------|-----------------|
| Video | `video_url` | `title`, `description` |
| Theory | `text_content` | `media[]` |
| Simulation | `simulation_id`, `screens[]`, `hotspots[]`, `transitions[]` | — |
| Quiz | `questions[]`, `passing_score` | `max_attempts` |
| CheatSheet | `content` | `downloadable_url`, `downloadable_name` |

---

## Validation Rules

### Course Level
- Title: required, 1-200 chars
- Description: optional, max 2000 chars

### Lesson Level
- Title: required, 1-200 chars
- Order: required, unique per course, sequential

### Module Level
- Type: required, one of [video, theory, simulation, quiz, cheatsheet]
- Order: required, unique per lesson, sequential
- Content: required, schema depends on type (see above)

### Publish Blockers
- No lessons
- Lesson without modules
- Module without content (per type validation above)
- Simulation with dead-end flows
- Quiz without questions

---

## Future Enhancements (Out of MVP Scope)
- Bulk import/export (JSON, SCORM)
- Course templates
- Collaborative editing
- Version history / rollback
- A/B testing for modules
- Analytics per module completion

---

## Related Documents
- `.context/product/course_builder_platform.md` — overall platform concept
- `.context/architecture/database_models.md` — DB schema reference
- `.context/product/lesson_flow_redesign.md` — lesson structure design
