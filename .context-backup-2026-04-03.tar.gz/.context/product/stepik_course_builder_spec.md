# Stepik-like Course Builder Specification

## 1. Target Model

**Hierarchy:**
```
Course (metadata, status)
 └─ CourseLesson (order_index, title, description)
     └─ LessonTask (order_index, type, required, payload)
```

**Task Types (MVP):**
- `theory_text` — markdown content + assets
- `theory_video` — video URL + duration + transcript
- `quiz` — questions, options, pass_score, attempt_limit, shuffle
- `simulation` — image, hotspots, transitions, is_start/is_completion
- `cheat_sheet` — reference text/links

**Versioning:**
- Course has mutable `draft` version
- Pipeline: `draft -> review -> approved -> published`
- `published` is immutable snapshot
- Any edit after publish = create new draft (clone from published)
- Student enrolled to specific version

## 2. UX Flow (Web Admin)

1. **Create Course** (metadata: title, slug, description, cover)
2. **Add Lessons** (drag&drop reorder, archive/restore)
3. **Build Lesson** (add tasks from library/templates, reorder, mark required/optional)
4. **Validate** (auto-check: no empty lessons, unique order_index, quiz/simulation valid)
5. **Preview** (live view as student sees)
6. **Submit Review** (draft -> review)
7. **Moderation** (approve/reject with comments)
8. **Publish** (approved -> published, snapshot created)
9. **History/Diff** (compare versions, rollback if needed)

## 3. Backend Implementation Plan

### 3.1 Database Schema (New Tables)

**course_lessons:**
- `id` (UUID, PK)
- `course_id` (UUID, FK → courses.id, cascade delete)
- `title` (String 255)
- `description` (Text, nullable)
- `order_index` (Integer, 1-10000)
- `status` (String: draft/active/archived)
- `created_at`, `updated_at` (DateTime)
- Unique: `(course_id, order_index)`

**lesson_tasks:**
- `id` (UUID, PK)
- `lesson_id` (UUID, FK → course_lessons.id, cascade delete)
- `task_type` (String: theory_text/theory_video/quiz/simulation/cheat_sheet)
- `title` (String 255)
- `order_index` (Integer, 1-10000)
- `required` (Boolean, default true)
- `payload_json` (JSONB)
- `checksum` (String 64)
- `created_at` (DateTime)
- Unique: `(lesson_id, order_index)`, `(lesson_id, task_key)` if added

**course_versions:**
- `id` (UUID, PK)
- `course_id` (UUID, FK → courses.id)
- `version` (String 32, e.g. "1.0.0")
- `changelog` (Text, nullable)
- `status` (String: draft/review/approved/published)
- `snapshot_json` (JSONB — full course structure snapshot)
- `published_at` (DateTime, nullable)
- `created_at` (DateTime)
- Unique: `(course_id, version)`

### 3.2 API Endpoints

**Lessons CRUD:**
- `POST /catalog/courses/{course_id}/lessons` — create lesson
- `GET /catalog/courses/{course_id}/lessons` — list lessons (ordered)
- `GET /catalog/lessons/{lesson_id}` — get lesson with tasks
- `PUT /catalog/lessons/{lesson_id}` — update lesson
- `DELETE /catalog/lessons/{lesson_id}` — archive lesson
- `POST /catalog/lessons/{lesson_id}/reorder` — reorder (move to position N)
- `POST /catalog/lessons/{lesson_id}/restore` — restore archived

**Tasks CRUD:**
- `POST /catalog/lessons/{lesson_id}/tasks` — create task
- `GET /catalog/lessons/{lesson_id}/tasks` — list tasks (ordered)
- `GET /catalog/tasks/{task_id}` — get task
- `PUT /catalog/tasks/{task_id}` — update task payload
- `DELETE /catalog/tasks/{task_id}` — archive task
- `POST /catalog/tasks/{task_id}/reorder` — reorder
- `POST /catalog/tasks/{task_id}/duplicate` — duplicate task in same lesson
- `POST /catalog/tasks/{task_id}/restore` — restore archived

**Library:**
- `GET /catalog/library/tasks` — list reusable task templates
- `POST /catalog/library/tasks` — create library item
- `POST /catalog/lessons/{lesson_id}/tasks/from-library` — insert copy

**Versions:**
- `POST /catalog/courses/{course_id}/versions/snapshot` — create snapshot
- `GET /catalog/courses/{course_id}/versions` — list versions
- `GET /catalog/courses/{course_id}/versions/{version_id}/diff` — compare versions
- `POST /catalog/courses/{course_id}/versions/{version_id}/publish` — publish

**Validation:**
- `POST /catalog/courses/{course_id}/validate` — run full validation
- Returns errors per lesson/task with severity

### 3.3 Service Layer

**CatalogService extensions:**
- `create_course_lesson(course_id, payload)` — create lesson
- `list_course_lessons(course_id)` — list ordered lessons
- `update_lesson(lesson_id, payload)` — update
- `archive_lesson(lesson_id)` — soft delete
- `reorder_lesson(lesson_id, new_index)` — transactional reindex
- `create_task(lesson_id, payload)` — create task
- `list_tasks(lesson_id)` — list ordered tasks
- `update_task(task_id, payload)` — update
- `archive_task(task_id)` — soft delete
- `duplicate_task(task_id)` — clone within lesson
- `reorder_task(task_id, new_index)` — transactional reindex
- `create_snapshot(course_id, version, changelog)` — snapshot structure to JSONB
- `list_versions(course_id)` — list versions
- `get_version_diff(version_a, version_b)` — structural diff
- `publish_version(version_id)` — transition to published
- `validate_course_structure(course_id)` — full validation

**Validators:**
- `LessonValidator` — no empty lessons, title length, order uniqueness
- `TaskValidator` — type-specific payload validation
- `QuizValidator` — questions/options/pass_score consistency
- `SimulationValidator` — start/completion/reachable graph (reuse existing)
- `CourseValidator` — at least 1 lesson, all lessons valid, publish guard

### 3.4 Repository Layer

**CatalogRepository extensions:**
- `create_lesson(course_id, title, description, order_index, status)`
- `list_lessons_by_course(course_id, include_archived)`
- `get_lesson_by_id(lesson_id)`
- `update_lesson(lesson_id, **fields)`
- `archive_lesson(lesson_id)`
- `get_next_order_index(course_id)` — for auto-ordering
- `reorder_lesson_within_course(course_id, lesson_id, new_index)` — transactional
- `create_task(lesson_id, task_type, title, order_index, required, payload, checksum)`
- `list_tasks_by_lesson(lesson_id, include_archived)`
- `get_task_by_id(task_id)`
- `update_task(task_id, **fields)`
- `archive_task(task_id)`
- `duplicate_task_within_lesson(task_id, new_order_index)`
- `reorder_task_within_lesson(lesson_id, task_id, new_index)`
- `create_version(course_id, version, changelog, status, snapshot_json)`
- `list_versions_by_course(course_id, limit)`
- `get_version_by_id(version_id)`
- `publish_version(version_id, published_at)`

## 4. Frontend Implementation Plan (Web Admin)

### 4.1 New Components

**CourseBuilderWorkspace** (`/catalog?tab=builder`):
- Left panel: Lessons list (drag&drop)
- Center: Tasks editor for selected lesson
- Right panel: Task properties inspector
- Top bar: Course metadata, validate/preview/publish actions

**LessonListPanel:**
- Draggable lesson items
- Add lesson button
- Archive/restore toggle
- Inline rename

**TaskEditor:**
- Task type selector (dropdown: theory_text/video/quiz/simulation/cheat_sheet)
- Type-specific form fields
- Required/optional toggle
- Duplicate/delete actions
- Drag handle for reorder

**TaskLibraryPicker:**
- Modal/sidebar with searchable library
- Preview task template
- "Insert as copy" button

**LivePreview:**
- Fullscreen modal
- Student view simulation
- Navigate lesson by lesson, task by task

**VersionDiffViewer:**
- Side-by-side comparison
- Highlight added/removed/reordered lessons/tasks
- Changed payload fields expandable

### 4.2 State Management

**Builder state:**
- `selectedCourseId`
- `lessons: LessonDraft[]` (local draft with localId for new items)
- `selectedLessonId`
- `tasks: TaskDraft[]` (for selected lesson)
- `saveState: 'clean' | 'dirty' | 'saving' | 'saved' | 'error'`
- `validationErrors: ValidationError[]`
- `autosaveTimer` (30s debounce)

**Actions:**
- `addLesson()` / `removeLesson(lessonId)` / `moveLesson(lessonId, newIndex)`
- `addTask(lessonId, type)` / `removeTask(taskId)` / `moveTask(taskId, newIndex)`
- `updateTaskPayload(taskId, payload)`
- `duplicateTask(taskId)`
- `saveDraft()` (debounced autosave + manual save)
- `validate()` (trigger validation, show errors)
- `preview()` (open live preview modal)
- `publish()` (create snapshot, transition to published)

### 4.3 API Integration

**Client functions** (`web/src/features/catalog/builder-api.ts`):
- `createCourseLesson(courseId, payload)`
- `listCourseLessons(courseId)`
- `updateLesson(lessonId, payload)`
- `archiveLesson(lessonId)`
- `reorderLesson(lessonId, newIndex)`
- `createLessonTask(lessonId, payload)`
- `listLessonTasks(lessonId)`
- `updateTask(taskId, payload)`
- `archiveTask(taskId)`
- `duplicateTask(taskId)`
- `reorderTask(taskId, newIndex)`
- `createCourseVersion(courseId, version, changelog)`
- `listCourseVersions(courseId)`
- `getVersionDiff(courseId, versionA, versionB)`
- `publishVersion(versionId)`
- `validateCourse(courseId)`

## 5. MVP Priorities

**Phase 1 (Core):**
- Backend: Lesson/Task CRUD + reorder + archive
- Frontend: Basic builder UI (add/edit/reorder lessons/tasks)
- Validation: Basic (no empty lessons, unique order)

**Phase 2 (Library):**
- Backend: Task library CRUD + insert-as-copy
- Frontend: Library picker modal + search
- Templates: Quick insert "Theory→Quiz→Simulation→CheatSheet"

**Phase 3 (Preview + Autosave):**
- Frontend: Live preview modal
- Autosave (30s debounce)
- Inline validation errors

**Phase 4 (Versioning + Diff):**
- Backend: Snapshot + version list + diff
- Frontend: Version diff viewer
- Publish flow with validation gates

**Phase 5 (Hardening):**
- Backend: Full test coverage (unit + integration)
- Frontend: E2E smoke tests
- Performance: Reorder optimization, large course handling

## 6. Migration Strategy

**Backward compatibility:**
- Existing `course_releases` + `course_release_screens` remain for mobile delivery
- New `course_lessons` + `lesson_tasks` used for authoring
- Snapshot transforms lessons/tasks → release/screens format
- Old flat releases still queryable for legacy mobile clients

**Migration path:**
1. Add new tables (non-breaking)
2. Build new authoring UI alongside old release builder
3. Deprecate old release builder after adoption
4. Optional: migrate existing releases to lesson/task structure

## 7. Acceptance Criteria

**Phase 1 Done:**
- Can create course with 3 lessons
- Can add/reorder/archive lessons
- Can add/reorder/archive tasks of each type
- Validation blocks publish if lessons empty
- Lint/tests pass

**Phase 2 Done:**
- Can create task library item
- Can search and insert library task as copy
- Quick templates work (1-click lesson structure)

**Phase 3 Done:**
- Live preview shows course as student sees
- Autosave triggers every 30s (and on blur)
- Inline validation errors highlight problematic lessons/tasks

**Phase 4 Done:**
- Can create version snapshot
- Can view diff between versions
- Publish blocked until validation passes
- Published version immutable

**Full MVP Done:**
- All phases complete
- E2E flow: create course → build lessons → preview → validate → publish
- No regressions in mobile course delivery

## 8. Open Decisions

**To be clarified:**
- [ ] Task library scope: global or per-course?
- [ ] Collaborative editing locks needed?
- [ ] Import/export format (JSON/SCORM)?
- [ ] Student progress model: per-task or per-lesson?
- [ ] Prerequisites between lessons?

---

*Created: 2026-03-30 | Status: In Implementation (Phase 1)*
