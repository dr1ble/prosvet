# Web Admin Useflow (MVP)

## 1. Purpose
This document defines full web-admin user flows for the MVP.

Primary product mission:
- quickly build and update digital literacy courses for older adults,
- publish high-quality simulation content fast,
- keep learning flow simple and safe.

Primary business KPIs:
- reduce time from content idea to published release,
- reduce time-to-learn for end users.

## 2. Scope
Included in MVP web-admin:
- auth and session entry,
- dashboard with role-based function tiles,
- full course authoring toolkit,
- no-code simulation builder,
- moderation and release publication,
- group and assignment management,
- progress overview,
- global search,
- DB-only audit trail.

Excluded from MVP:
- notification center,
- advanced analytics dashboards,
- UI for full audit history.

## 3. Roles
- `Administrator`:
  - full access,
  - role and permission management,
  - operational override.
- `Methodologist`:
  - creates and edits course content,
  - builds simulations,
  - submits release for review.
- `Moderator`:
  - reviews and approves content,
  - controls publication quality,
  - can manage groups.
- `Curator`:
  - manages groups,
  - assigns users,
  - tracks progress,
  - can manage published content according to action-level permissions.

## 4. Information Architecture
Top-level screens after auth:
1. `Dashboard` (entry hub with tiles).
2. `Catalog` (courses, modules, lessons, screens).
3. `Simulation Builder` (canvas, hotspots, graph).
4. `Moderation Queue` (review, approve, reject, publish).
5. `Groups` (class-like entities and assignments).
6. `Users` (basic management, roles where allowed).
7. `Progress` (lesson completion by users/groups).

Global shell:
- top bar with global search,
- role badge and profile menu,
- language switch (RU/EN),
- context breadcrumbs.

## 5. Domain Model for Authoring
Content hierarchy:
- `Course -> Module -> Lesson -> Screen`.

Isolation rule (MVP):
- course is an isolated content unit,
- modules/lessons/screens are not shared across courses,
- one lesson belongs to exactly one module,
- one module belongs to exactly one course.

Simulation-capable lesson includes screens and graph:
- `Screen` types: `video`, `simulation`, `quiz`, `summary`.
- `Hotspot`: clickable rectangle/polygon with action.
- `Transition`: edge from hotspot to next screen.
- `Hint`: guided help text/overlay per screen/hotspot.

Release model:
- lifecycle: `draft -> review -> approved -> published`.
- compatibility: `app_version_range`.
- delete policy: soft delete only.
- published release editing: allowed (business decision).

Progress model (MVP):
- based on completed lessons.
- statuses: `not_started`, `in_progress`, `completed`.
- `overdue` is not used in MVP unless deadlines are introduced.

## 6. End-to-End Useflows

### UF-01: Authentication and Session Start
Actor: all roles.

Preconditions:
- user has login/password and role in system.

Main flow:
1. User opens `/auth`.
2. User enters login and password.
3. System verifies credentials and creates secure session.
6. User is redirected to `Dashboard`.

Errors:
- invalid credentials,
- rate limit reached,
- temporary lock by security policy.

Success outcome:
- active admin session,
- role-specific dashboard tiles available.

### UF-02: Dashboard Navigation Hub
Actor: all roles.

Main flow:
1. User lands on dashboard.
2. System shows only allowed tiles based on action permissions.
3. User enters selected function area.

UX rules:
- no duplicated onboarding hints,
- one clear primary action per tile,
- recent activity block can be added later.

### UF-03: Create Course
Actor: `methodologist`, `admin`.

Main flow:
1. Open `Catalog`.
2. Click `Create Course`.
3. Fill metadata:
   - required: `title`,
   - optional: `slug` (auto-generated if empty), `description`, `cover`.
4. Save draft course.
5. System creates initial empty course tree.

Validation:
- title required,
- unique slug if provided,
- safe image format for cover.

### UF-04: Build Course Structure (Modules and Lessons)
Actor: `methodologist`, `admin`.

Main flow:
1. Open course tree.
2. Add module(s).
3. Add lesson(s) inside module.
4. Reorder modules and lessons via drag-and-drop.
5. Save structure.

Module required fields:
- `title`,
- `order_index`.

Module optional fields:
- `description`,
- `status` (`active`/`archived`).

Lesson required fields baseline:
- `title`,
- `type`,
- `estimated_duration`.

Lesson optional fields baseline:
- `pass_score` (for relevant lesson types).

Quiz configuration (MVP):
- required:
  - `time_limit`.
- optional:
  - `passing_score`,
  - `attempt_limit`,
  - `shuffle_questions`.

Soft-delete behavior:
- archive module/lesson instead of hard delete.

### UF-05: No-Code Simulation Builder
Actor: `methodologist`, `admin`.

Main flow:
1. Open lesson in `Simulation Builder`.
2. Upload/select screenshots.
3. Create screens and order them.
4. Draw clickable hotspots on screen canvas.
5. Configure action for each hotspot.
6. Link hotspots to next screens in flow graph.
7. Add hints per hotspot/screen.
8. Save simulation draft.

Editor layout:
- left: course tree and screen list,
- center: screenshot canvas,
- right: property inspector,
- bottom: transition graph.

Hint model:
- level 1: nudge,
- level 2: explicit text,
- level 3: highlight target zone.

### UF-06: Lesson Preview and Validation
Actor: `methodologist`, `admin`, `moderator`.

Main flow:
1. Click `Preview`.
2. Run learner path from first screen.
3. Validate successful and wrong actions.
4. Fix found issues.

Publish blockers:
- missing entry screen,
- unreachable screen,
- dead-end flow without completion path,
- too-small hotspots,
- missing required metadata.

### UF-07: Submit Release for Review
Actor: `methodologist`, `admin`.

Main flow:
1. Select course release draft.
2. Set `app_version_range`.
3. Run final validation.
4. Click `Submit for review`.
5. Release status changes `draft -> review`.

### UF-08: Moderation Review and Approval
Actor: `moderator`, `admin`.

Main flow:
1. Open moderation queue.
2. Review submitted release.
3. Add comments and decision.
4. Approve or reject.
5. If approved, status `review -> approved`.
6. If rejected, status returns to editable state with reason.

### UF-09: Publish Release
Actor: `moderator`, `admin`.

Main flow:
1. Open approved release.
2. Verify metadata and compatibility range.
3. Publish release.
4. Status `approved -> published`.
5. Mobile delivery endpoint serves this version according to compatibility.

### UF-10: Edit Published Release (Business Decision)
Actor: `methodologist`, `curator`, `moderator`, `admin`.

Main flow:
1. Open published release.
2. Edit allowed entities.
3. Save changes.
4. System logs audit event with actor and diff metadata.

Risk note:
- this is faster operationally,
- but weaker for strict audit and reproducibility than immutable publish model.

### UF-11: Group Management and Assignment
Actor: `curator`, `moderator`, `admin`.

Main flow:
1. Create group (class).
2. Add users to group.
3. Assign course to group and optional individual users.
4. Configure start policy.
5. Monitor assignment status.

Rules:
- one user may belong to multiple groups,
- user may exist without group,
- assignment supports group-level and user-level targeting.

### UF-12: Progress Tracking
Actor: `curator`, `moderator`, `admin`.

Main flow:
1. Open progress page.
2. Filter by group/user/course.
3. View completion metrics based on completed lessons.
4. Detect learners who are stuck in progress.

MVP widgets:
- completion rate by group,
- completion rate by course,
- learners with low completion.

### UF-13: Global Search
Actor: all roles (within permission scope).

Main flow:
1. Enter query in global search.
2. System returns grouped results:
   - courses,
   - lessons,
   - users,
   - groups.
3. User navigates to selected entity.

Rules:
- search respects role permissions,
- archived entities are marked clearly.

### UF-14: Archive and Restore
Actor: roles with archive permission.

Main flow:
1. User archives course/module/lesson/release.
2. Entity is hidden from default active lists.
3. User can restore archived entities if allowed.

Rule:
- hard delete is disabled in MVP.

## 7. Flexible Permission Model (No Hardcode)

Decision:
- do not hardcode role matrix in frontend/backend logic.
- use dynamic permission policy loaded from DB.

Permission primitives:
1. `resource`:
- `course`, `module`, `lesson`, `screen`, `release`, `group`, `assignment`, `user`, `role`, `progress`.
2. `action`:
- `create`, `read`, `update`, `archive`, `restore`, `submit_review`, `approve`, `reject`, `publish`, `assign`.
3. `scope`:
- `global`, `group`, `own`.
4. `effect`:
- `allow` / `deny`.

Recommended data model:
- `roles`
- `permissions`
- `role_permissions`
- `user_roles`

Evaluation rule:
1. collect permissions from the user's single assigned role,
2. apply explicit denies first,
3. then apply allows by scope and conditions.

MVP implementation strategy:
1. Create default role templates:
- `admin`, `methodologist`, `moderator`, `curator`.
2. Store templates as DB seed data (editable later).
3. Add permission management UI for admin:
- role editor,
- action toggles per resource,
- preview “what this role can do”.
4. Frontend renders actions from `/me/permissions` response.
5. Backend enforces policy on every protected endpoint.

MVP policy constraints:
- one user can have only one active role at a time,
- no per-user permission overrides in MVP,
- policy updates are allowed only for `admin`,
- every policy change is audit-logged in DB (`who`, `when`, `what changed`),
- no policy versioning/rollback UI in MVP.

Important:
- this keeps product flexible for future orgs/teams,
- role names can stay stable while permissions evolve safely.

## 8. UX Requirements
- Keep admin flow minimal and task-first.
- Avoid repeated explanatory hints on every screen.
- Use consistent primary action placement.
- Support keyboard and clear focus states.
- Show validation in-context near edited fields.
- Keep drag-and-drop usable with fallback controls for precision.
- Forbidden actions should be hidden (not rendered as disabled controls).

## 9. Non-Functional Expectations
- Save latency for normal edits: target less than 1 second.
- Builder canvas interactions should remain smooth on mid-range laptops.
- All critical state changes should be audit-logged in DB.
- Session and API routes must remain role-safe under direct URL access.

## 10. MVP Delivery Plan (Web Admin)
1. Auth + dashboard shell + permission-aware navigation.
2. Course structure CRUD with drag-and-drop.
3. Simulation builder (canvas + hotspots + transitions + hints).
4. Validation and preview.
5. Release review/approve/publish flow.
6. Group assignment and progress page.
7. Global search.

Analytics extension:
- deliver after authoring toolkit reaches operational completeness.

## 11. Open Questions to Finalize
1. No open questions for MVP useflow.
